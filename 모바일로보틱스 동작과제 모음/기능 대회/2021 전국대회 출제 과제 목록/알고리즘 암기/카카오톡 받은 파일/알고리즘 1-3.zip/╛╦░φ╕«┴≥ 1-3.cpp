#include <stdio.h>
int pow(int n, int t);

int main(void)
{
	int a, b;
	
	printf("�Է�\n");
	scanf("%d %d", &a, &b);
	printf("%d", pow(a,b) );
	
	return 0;
}
int pow(int n, int t)
{
	if(t == 0)
	return 1;
	return n*pow(n, t-1);
}
