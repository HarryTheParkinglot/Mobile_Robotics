#include <stdio.h>

int main(){
	int rec[5][5] = {0,};
	int ax[4][2]={0,};
	
	int i,j,n,m;
	
	for(i=0;i<4;i++){
		scanf("%d %d",&ax[i][0],&ax[i][1]);
		rec[ax[i][0]][ax[i][1]]=1;	
	}
	
	n=1;
	for(i=ax[0][0];i<ax[3][0];i++){
		rec[ax[0][0]][ax[0][1]+n]=1;
		rec[ax[0][0]+n][ax[0][1]]=1;
		n++;
	}
	
	n=1;
	for(i=ax[3][0];i>ax[0][0];i--){
		rec[ax[3][0]][ax[3][1]-n]=1;
		rec[ax[3][0]-n][ax[3][1]]=1;
		n++;
	}

	n=1;
	for(i=ax[0][0];i<ax[3][0]-1;i++){
		rec[ax[0][0]+n][ax[0][1]+n]=2;
		if(ax[2][0]!=0){
			rec[ax[2][0]-n][ax[2][1]+n]=2;
		}
		else 
			rec[ax[2][0]+n][ax[2][1]-n]=2;
		n++;
	}
	
	
	for(i=0;i<5;i++){
		for(j=0;j<5;j++){
			printf("%d ",rec[i][j]);			
		}
		printf("\n");
	}
	for(i=0;i<4;i++){
		for(j=0;j<2;j++){
			printf("%d ",ax[i][j]);			
		}
		printf("\n");
	}
	
	
}
