#include<stdio.h>
main(){
	int box[3][2] = {0};
	int m; 
	int arr[1000][2] = {0};
	
	printf("���ڿ� ���� ���� �Է� : ");
	scanf("%d%d%d",&box[0][0],&box[1][0],&box[2][0]);
	printf("�� ���� : ");
	scanf("%d", &m);
	for(int i = 0 ; i < m ; i++){
		scanf("%d", &arr[i][0]);
		for(int j = 0 ; j < 3 ; j++){
			if(box[j][0] == arr[i][0]){
				printf("arr : %d	",arr[i][1] = j);
				printf("box n : %d\n",box[j][1]+=1);
				break;
			}
		}
	}
	
	printf("%d %d %d\n",box[0][1],box[1][1],box[2][1]);
	for(int i = 0 ; i < m ; i++){
		printf("%d ", arr[i][1]);
	}
}
