#include<stdio.h>
main(){
	int box[10000][2] = {0};
	int arr[10000][2] = {0};
	int n, m, co = 0; 
	int chk[10000][2] = {0};
	scanf("%d", &n);
	for(int i = 0 ; i < n ; i++){
		scanf("%d", &box[i][0]);
	}
	scanf("%d", &m);
	for(int i = 0 ; i < m ; i++){
		scanf("%d", &arr[i][0]);
	}
	for(int i = 0 ; i < m ; i++){
		for(int j = 0 ; j < n ; j++){
			if((arr[j][1]==0)&&(box[j][1]==0)&&(box[j][0] == arr[i][0])){
				box[j][1]=1;
				arr[i][1]=1;
				chk[co][0] = box[j][0]+1;
				chk[co][1] = i+1;
				co++;
				break;
			}
		}
	}
	for(int i = 0 ; i < 2 ; i++){
		for(int j = 0 ; j < m+n; j++){
			if(chk[j][i]==0)	break;
			printf("%d ", chk[j][i]-1);
		}
		printf("\n");
	}
	printf("���� ���� : ");
	for(int i = 0; i < n; i++){
		if(box[i][1]==0) printf("%d, ",i);
	}
	printf("\b\b�� ����\n");
	
	
	printf("���� �� : ");
	for(int i = 0; i < m; i++){
		if(arr[i][1]==0) printf("%d, ",i);
	}
	printf("\b\b�� ��");
}
