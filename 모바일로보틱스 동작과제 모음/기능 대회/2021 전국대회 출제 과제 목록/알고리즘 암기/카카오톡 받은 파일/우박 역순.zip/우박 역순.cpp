	#include<stdio.h>
int tmp[100000];
int i=0;
void oubak(int a){
	if(a!=1){
		if(a%2==0){
			a/=2;
			tmp[i]=a;
			i++;
			printf("%d\n",a);
			oubak(a);
		}
		else{
			a=3*a+1;
			tmp[i]=a;
			i++;
			printf("%d\n",a);
			oubak(a);
		}
	}
}
int main(void){
	int n;
	scanf("%d",&n);
	printf("%d\n",n);
	oubak(n);
	while(i--){
		printf("%d\n",tmp[i]);
	}
	printf("%d\n",n);
	return 0;
}
