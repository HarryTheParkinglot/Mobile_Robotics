#include <stdio.h>

#define M 8

int link[M+1][M-1] = {
   {0},					//0
   {2,3,4,7},			//1
   {1,3,5},				//2
   {1,2,4,5,6,7,8},		//3
   {1,3,7},				//4
   {2,3,6,8},			//5
   {3,5,7,8},			//6
   {1,3,4,6,8},			//7
   {3,5,6,7}			//8
};
int dis[M+1][M-1] = {
   {0},					//0
   {3,1,2,3},			//1
   {3,1,1},				//2		---2�� 3 ������ �Ÿ��� ��� ���Ƿ� �����߽��ϴ�. 
   {1,1,2,2,3,2,2},		//3
   {2,2,1},				//4
   {1,2,5,3},			//5
   {3,5,2,1},			//6
   {3,2,1,2,3},			//7
   {2,3,1,3}			//8
};
int route[M] = {0};
int chk[M + 1] = {0};
int sr[M] = {0};
int sd=100;



void DFS(int p, int g, int dp, int cm){
	route[dp] = p;
	if(cm>sd){
		return;	//�ִ� �Ÿ����� �� ��� �� �ʿ䰡 �����Ƿ� �н� 
	}	
	if(p == g){
   		if(cm<sd){
   			for(int i = 0 ; i < M ; i++){
      		if(i<=dp)	sr[i] = route[i];	//	printf("%d ",);
			else		sr[i] = 0;
		}
	//	printf("\t%d", cm);
    //	printf("\n");
    	sd=cm;
		}
    	return;
	}
   
	chk[p] = 1;
   
	for(int i = 0 ; i < M ; i++){
    	int np = link[p][i];
    	if(np <= 0 || chk[np]) continue;
    	DFS(np,g,dp+1,cm+dis[p][i]);
	}
	chk[p] = 0;
	return;
}

int main(){
	int st, g;
	printf("������ġ : ");
	scanf("%d", &st);
	printf("������ġ : ");
	scanf("%d", &g);
	DFS(st,g,0,0);
	printf("��� : ");
	for(int i = 0;i < M ; i++){
		if(sr[i]==0)	break;
		printf("%d ", sr[i]);
	}
	printf("\n���� : %d", sd);
}
