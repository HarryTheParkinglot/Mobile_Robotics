#include <stdio.h>
void f(int n) {
   printf("%d\n", n);
   if(n == 1)
   return;
   if(n % 2 == 0)
   f(n / 2);
   else
   f(n*3 + 1);
}
void x(int n) {
   
   if(n == 1){}
   
   else if(n % 2 == 0)
   x(n / 2);
   else
   x(n*3 +1);
   printf("%d\n", n);
}
int main() {
   int n;
   scanf("%d", &n);
   
  f(n);
  x(n);
} 
