#include <stdio.h>
  
int main()
{
	int box1, box2, box3;
	int f = 0, s = 0, t = 0;
	
	int m;
	
	int index[20];
	int ball[20];
	 ////////////////////////// �Է� 
	scanf("%d %d %d", &box1, &box2, &box3);
	
	scanf("%d", &m);
	
	for(int i = 0; i < m; i++) 	
		scanf("%d", &ball[i]);
		
	
	for(int i = 0; i < m; i++)
	{
		if(ball[i] == box1)
		{
			index[i] = box1 - 1;
			f++;
		}
		else if(ball[i] == box2)
		{
			index[i] = box2 - 1;
			s++;
		}
		else if(ball[i] == box3)
		{
			index[i] = box3 - 1;
			t++;
		}
	}
	
	
	
	printf("%d %d %d\n", f, s, t);
	
	for(int i = 0; i < m; i++)
	{
		printf("%d ", index[i]);
	}
}
