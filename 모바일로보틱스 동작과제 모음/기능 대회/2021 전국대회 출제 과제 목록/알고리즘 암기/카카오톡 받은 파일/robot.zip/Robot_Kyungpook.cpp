#include <iostream>
#include "Robot_Kyungpook.h"

using namespace std;

int main() {
	GenerateMap();
	ScanA();

	if (!col_a[4])
		FillACenter();

	GetGoalA();

	MatchA();

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++)
			printf("%d ", gol_a[i * 3 + j]);

		printf("\n");
	}

	printf("\n");

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++)
			printf("%d ", col_a[i * 3 + j]);

		printf("\n");
	}

	printf("%d", CanPlacePuckA(3));
	return 0;
}