#pragma once
#include <memory.h>

// A
//	0	1	2
//	3	4	5
//	6	7	8

// B
//	0	1	2	3
//	4	5	6	7
//	8	9	10	11
//	12	13	14	15
//	16	17	18	19

// input variables.
int input_a[9] = {
	1, 0, 2,
	2, 1, 0,
	3, 2, 0
};
int input_b[20] = {
	0, 0, 0, 0,
	0, 0, 0, 3,
	3, 0, 0, 0,
	3, 0, 2, 0,
	0, 1, -1, 2
};
int input_c = 1;
int input_d[2] = { 6, 8 };
int input_prio[3] = { 1, 3, 2 };

// using variables.
int map_a[9][9];
int map_b[20][20];
int col_a[9];
int col_b[20];
int gol_a[9];
int dfs_path[20];
int min_len = 0;
int min_path[20];

// map data.
int GetPosA(int p, int d) {
	int r = -1;
	switch (d)
	{
	case 0:
		if (p / 3 != 0)
			r = p - 3;
		break;

	case 1:
		if (p % 3 > 0)
			r = p - 1;
		break;

	case 2:
		if (p / 3 != 2)
			r = p + 3;
		break;
	case 3:
		if (p % 3 != 2)
			r = p + 1;
		break;
	}

	return r;
}

int GetPosB(int p, int d) {
	int r = -1;
	switch (d)
	{
	case 0:
		if (p / 4 != 0)
			r = p - 4;
		break;

	case 1:
		if (p % 4 > 0)
			r = p - 1;
		break;

	case 2:
		if (p / 4 != 4)
			r = p + 4;
		break;

	case 3:
		if (p % 4 != 3)
			r = p + 1;
		break;
	}

	if (p == 0 || p == 3 || r == 0 || r == 3 || (p == 1 && r == 2) || (p == 2 && r == 1))
		r = -1;

	return r;
}

void GenerateMap() {
	for (int i = 0; i < 9; i++) {
		for (int j = 0; j < 4; j++) {
			int p = GetPosA(i, j);
			if (p >= 0)
				map_a[i][p] = 1;
		}
	}

	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 4; j++) {
			int p = GetPosB(i, j);
			if (p >= 0)
				map_b[i][p] = 1;
		}
	}
}

void MovePuck(int* board, int f, int t) {
	board[t] = board[f];
	board[f] = 0;
}

void ScanA() {
	memcpy(col_a, input_a, sizeof(int) * 9);
}

void FillACenter() {
	// ����� ������� ���.
	if (!col_a[4]) {
		// �켱������ �˻��ؼ� �Ű���.
		int pr[8] = { 1, 5, 7, 3, 0, 2, 6, 8 };
		for (int i = 0; i < 8; i++) {
			if (col_a[pr[i]])
			{
				MovePuck(col_a, pr[i], 4);
				break;
			}
		}
	}
}

int GetDistToGoalA(int* goal) {
	int c = 0;
	for (int i = 0; i < 9; i++) {
		if (goal[i] != col_a[i])
			c++;
	}

	return c;
}

void GetGoalA() {
	int colIndex[4][2] = {
		{0, 0},
		{2, 3},
		{1, 3},
		{1, 2}
	};
	int index[2][3][3] = {
		// LT to RB
		{
			{0, 4, 8},
			{1, 5, 6},
			{2, 3, 7}
		},
		{
			{2, 4, 6},
			{0, 5, 7},
			{1, 3, 8}
		}
	};
	
	int md = 100;
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			int g[9] = { 0 };
			for (int k = 0; k < 3; k++) {
				g[index[i][0][k]] = col_a[4];
				g[index[i][1][k]] = colIndex[col_a[4]][j];
				g[index[i][2][k]] = colIndex[col_a[4]][(j + 1) % 2];
			}

			int d = GetDistToGoalA(g);
			if (d < md) {
				memcpy(gol_a, g, sizeof(int) * 9);
				md = d;
			}
		}
	}
}

void MovePuckByPathA(int p, int *path, int pathLen) {
	for (int i = 0; i < pathLen; i++) {
		int pp = GetPosA(p, path[i]);
		MovePuck(col_a, p, pp);
		p = pp;
	}
}

void FindGoalAPosDfs(int p, int c) {
	if (!col_a[p])
		return;

	if (gol_a[p] == col_a[p])
	{
		if (c < min_len) {
			min_len = c;
			memcpy(min_path, dfs_path, sizeof(int) * min_len);
		}
	}
	else {
		for (int i = 0; i < 4; i++) {
			int pp = GetPosA(p, i);
			if (pp >= 0
				&& !col_a[pp])
			{
				col_a[pp] = col_a[p];
				dfs_path[c] = i;
				FindGoalAPosDfs(pp, c + 1);
				col_a[pp] = 0;
			}
		}
	}
}

void MatchA() {
	for (int i = 0; i < 9; i++) {
		if (col_a[i] && gol_a[i] != col_a[i]) {
			min_len = 100;
			FindGoalAPosDfs(i, 0);
			if (min_len != 100)
				MovePuckByPathA(i, min_path, min_len);
		}
	}
}

int CanPlacePuckA(int col) {
	int prio_index[7][3] = {
		{},
		{6, 7, 8}, {3, 4, 5}, {0, 1, 2},
		{0, 3, 6}, {1, 4, 7}, {2, 5, 8}
	};

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			int index = prio_index[input_prio[i]][j];
			if (!col_a[index] && gol_a[index] == col) {
				if (i > 0) {
					// ���� �켱���� ���� �˻�.
					for (int k = 0; k < 3; k++) {
						int ii = prio_index[input_prio[i - 1]][k];
						if (col_a[ii] != gol_a[ii])
							return 0;
					}
				}

				return 1;
			}
		}
	}

	return 0;
}

void PlacePuckToA(int p, int c) {
	col_a[p] = c;
}

void MoveBToA(int *b, int bpos, int apos) {
	MovePuck(b, bpos, input_c);
	PlacePuckToA(apos, col_b[input_c]);
}