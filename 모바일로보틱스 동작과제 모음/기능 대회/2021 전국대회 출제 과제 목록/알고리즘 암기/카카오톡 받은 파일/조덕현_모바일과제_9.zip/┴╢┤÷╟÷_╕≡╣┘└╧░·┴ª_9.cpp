#include <stdio.h>

int n=4,m;
int link[101][99] = {
	{0},
	{2,3,4},
	{1,3},
	{1,2,4},
	{1,3}
};
int route[100] = {0};
int chk[101] = {0};
int llink[100] = {0};
int slink[100] = {0};
int l=0,s=200;


void DFS(int p, int g, int dp){
	route[dp] = p;
	if(p == g){
		for(int i = 0 ; i <= dp ; i++)
			printf("%d ",route[i]);
		printf("\n");
		if(dp<s){
			s=dp;
			for(int i = 0 ; i <= s ; i++)
				slink[i] = route[i];
		}
		if(dp>l){
			l=dp;
			for(int i = 0 ; i <= l ; i++)
				llink[i] = route[i];
		}
    	return;
	}
	chk[p] = 1;
   
	for(int i = 0 ; i < n ; i++){
    	int np = link[p][i];
    	if(np <= 0 || chk[np]) continue;
    	DFS(np,g,dp+1);
	}
	chk[p] = 0;
	return;
}

int main(){
	int st = 1, g = 4;
	
	printf("��� ���� : ");
	scanf("%d", &n);
	for(int i = 1 ; i  <= n ; i++){
		printf("%d�� ���� ����� ��� ���� : ", i);
		scanf("%d", &m);
		printf("%d�� ���� ����� ��� : ", i);
		for(int j = 0 ; j < m ; j++){
			scanf("%d", &link[i][m]);
		}
	}

	printf("������ġ : ");
	scanf("%d", &st);
	printf("������ġ : ");
	scanf("%d", &g);
	
	DFS(st,g,0);
	
	printf("\n�ִ� ��� : ");
	for(int i = 0 ; i <= s ; i++)
		printf("%d ", slink[i]);
	printf("\n���� ��� : ");
	for(int i = 0 ; i <= l ; i++)
		printf("%d ", llink[i]);
}
