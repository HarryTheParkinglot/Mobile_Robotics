#include "Interface.h"
#include "math.h";

#define V3 while(!Cmd(0,19));
#define SV1 while(!Cmd(0,18));
#define cw		wa=0;
#define ar acf = cacf =0;
#define set pos[0] = pos[1] = pos[2] = 0;
#define wait SS(); while(SW3); while(!SW3);
#define rt bar_1 = bar_2 = bar_3 = bar_4 = bar_5 = sbar_1 = sbar_2 = 0;
#define lcs lcd_clear_screen(); 
int key = 0, key_puck = 0;
///////////////////

#define ab45    wa = 90; AB(0,0,4,223,5,210,50,0); cw

#define ab345(y) wa = 90; AB(3,197,4,230,5,208,50,y); cw
#define ab245(y) wa = 90; AB(2,223,4,230,5,208,50,y); cw
#define ab145(y) wa = 90; AB(1,128,4,230,5,208,50,y); cw

#define ab645(y) wa = 90; AB(6,233,4,230,5,208,50,y); cw
#define ab745(y) wa = 90; AB(7,231,4,230,5,208,50,y); cw
#define ab845(y) wa = 90; AB(8,117,4,230,5,208,50,y); cw

#define ab86 AB(0,0,6,221,8,104,50,0);
#define ab13 AB(0,0,1,122,3,186,50,0);

#define ab863(y) AB(3,122,6,221,8,104,50,y);
#define ab136(y) AB(6,221,1,122,3,186,50,y);

#define ab4(y) AB(4,220,0,0,0,0,0,y); cw
#define ab5(y) AB(5,134,0,0,0,0,0,y); cw
#define ab6(y) AB(6,89,0,0,0,0,0,y); cw
#define ab3(y) AB(3,115,0,0,0,0,0,y); cw
#define ab2(y) wa = 90; AB(2,230,0,0,0,0,0,y); cw
#define ab7(y) wa = 90; AB(7,235,0,0,0,0,0,y); cw
#define ab1(y) wa = 90; AB(1,170,0,0,0,0,0,y); cw
#define ab8(y) wa = 90; AB(8,127,0,0,0,0,0,y); cw
#define ab12(y)  AB(0,0,1,155,0,0,y,0); cw
#define ab82(y) AB(0,0,8,155,0,0,y,0); cw

#define ab1_40(y) wa = 90; AB(1,174,0,0,0,0,0,y); cw
#define ab8_40(y) wa = 90; AB(8,140,0,0,0,0,0,y); cw

#define ab1_45(y) wa = 90; AB(1,139,0,0,0,0,0,y); cw
#define ab8_45(y) wa = 90; AB(8,110,0,0,0,0,0,y); cw

#define ab865(y) AB(5,175,6,209,8,97,50,y);
#define ab134(y) AB(4,236,1,160,3,233,50,y);
#define ab34(y) AB(4,228,0,0,3,170,50,y);

#define CL(check, d, sp, ac) wa = -90, CBPsd(check,d,4,236,5,214,sp,ac), cw;
#define CR(check, d, sp, ac) wa = 90,  CBPsd(check,d,4,236,5,214,sp,ac), cw;

#define ab02(y) AB(0,200,0,0,0,0,0,y); cw
#define ab0(y) AB(0,238,0,0,0,0,0,y); cw
/////////////////////////////////////



int main(void)
{    
    Interface_init(); 
	
	LM629_HW_Reset();

	MCU_init();	   
	Sensor_init();
	sei();
	
	Motor_init();  
	_delay_ms(200);
	Camera_init();
	V3;
	TM(80);
	Setting(13);

	LED_ON(3);
	_delay_ms(100);
	LED_OFF(3);
	
	set
	
	while(1)
	{
		if(SW1) {

			key--;
			_delay_ms(70);
		}
		if(SW3) {

			key++;
			_delay_ms(70);
		}
		if(SW2) {
			lcd_clear_screen();
			switch(key) {

case 0:



///////////////////
SS();
LED_ON(0);
LED_ON(1);
LED_ON(2);
LED_ON(3);
_delay_ms(100);
LED_OFF(3);
LED_OFF(0);
LED_OFF(1);
LED_OFF(2);
while(!SW1);
while(SW1);
_delay_ms(70);
break;

			}
		}

			if (key) {
				lcd(0,0, "%03d %03d %03d %03d %03d", g_psd[2], g_psd[1], g_psd[0], g_psd[8], g_psd[7]);
				lcd(1,0, "%03d %03d     %03d %03d", g_psd[3], g_psd[4], g_psd[5], g_psd[6]);
			}
			else {
				lcd(0,0, "%03d %03d %03d %03d %03d", psd[2], psd[1], psd[0], psd[8], psd[7]);
				lcd(1,0, "%03d %03d     %03d %03d", psd[3], psd[4], psd[5], psd[6]);
			}

			key_puck = abs(key);
			lcd(2,0,"C%d X%3d Y%3d S%2d",key_puck,Cmd(key_puck, 102), Cmd(key_puck, 103), Cmd(key_puck, 104));
			lcd(3,0,"%d%d%d|%d%d %d%d%d|%d%d ",IR_1,IR_2,IR_3,IND_1,IND_2, bar_1, bar_2, bar_3, sbar_1, sbar_2, key_puck);
			lcd(3,16, "K:%02d", key);
	}   		
}
