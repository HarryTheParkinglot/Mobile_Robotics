#include "Omni.h"
#include "Interface.h"

volatile unsigned int gtc = 0;

int Omni(int x, int y, int z, int ang, int sp, int ac, double *msp, int sel)
{
	double xv[4] = {x,y,-z*M_PI/1.8/1.747,-ang*M_PI/1.8/1.747}, d=1, i1, i2;
	double mtp = 0;

	if(ac<100&&ac) d = 2;

	if(sel>=10) i1=i2=sel-10;
	else		i1=0,i2=3-sel;

	for(int i=i1; i<=i2; i++) if(mtp<fabs(xv[i])) mtp = fabs(xv[i]);
	for(int i=i1; i<=i2; i++) msp[i] = xv[i]/mtp*sp;

	if(ac>100) ac -= 100;

	return (mtp*100/sp) + (abs(ac)/d-1);
}

void OmniSet(int tot, int ac, volatile double *msp, volatile double *asp, int sel)
{
	int m = (ac<0||(ac>100 && ac<200))? 1: 0, i1, i2, ac2;
	if(ac>100) ac-= 100;
	ac2 = abs(ac);

	if(sel>=10) i1=i2=sel-10;
	else		i1=0,i2=3-sel;

	for(int i=i1; i<=i2; i++) {
		if(oc>=0&&!(ac<0))		asp[i] = (double)(msp[i] * (oc+1)/ac2);
		if(oc>=ac2||(ac<0))		asp[i] = msp[i];
		if(oc>=tot-ac2+1&&m)	asp[i]  =(double)(msp[i] * (tot-oc)/ac2);
		if(oc>tot+1)			asp[i] = 0;
	}
}
