#include <avr/io.h>

volatile extern unsigned char psd[], g_psd[];

void Camera_init(void);
unsigned char Cmd(unsigned char color, unsigned char cmd);
void Setting(unsigned char ins);
void Sensor_init(void);
