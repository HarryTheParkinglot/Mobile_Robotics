#include <stdio.h>
char co[5] = {'N','R','B','Y','\0'};
int arr[9] = {0};

void f(int dp){
	if(dp == 9){
		for(int i = 0 ; i < 9 ; i++){
			printf("%c", co[arr[i]]);
			if(i%3==2)	printf("\n");
		}
		printf("\n");
		arr[dp] = 0;
		return;
	}
	for(int i = 1 ; i <= 3 ; i++){
		if((arr[dp-1]!=i)&&(arr[dp-3]!=i)){
			arr[dp] = i;
			f(dp+1);	
		}
	}
	arr[dp] = 0;
	return;
}
int main(){
	f(0);
}
