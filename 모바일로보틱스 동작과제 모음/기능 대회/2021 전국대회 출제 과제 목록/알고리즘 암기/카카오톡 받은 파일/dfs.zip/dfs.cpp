#include <stdio.h>

#define M 5

int link[M+1][M-1] = {
   {0},
   {2,3,4,5},
   {1,3,4,5},
   {1,2,4,5},
   {1,2,3,5},
   {1,2,3,4}
};

int route[M] = {0};

int chk[M + 1] = {0};

int sroute[M]={0};
int lroute[M]={0};
int l=0,s=999;

void DFS(int p,int g,int dp){
	
	route[dp]=p;
	
	if(p==g){
		
		if(dp<s){
			s=dp;
			for(int i=0;i<=s;i++)
				sroute[i]=route[i];	
	}
	
		if(dp>l){
			l=dp;
			for(int i=0;i<=l;i++)
				lroute[i]=route[i];		
			
		}
		for(int i=0;i<=dp;i++)
			printf("%d ",route[i]);
			
		printf("\n");	
		return;
		
	}
	
	chk[p]=1;
	
	for(int i=0;i<M;i++){
		int np=link[p][i];
		if(np<=0||chk[np]) continue;
		DFS(np,g,dp+1);	
	}
	chk[p]=0;
	return;
}

int main(){
	DFS(1,4,0);	
	printf("\n���� �� ��Ʈ:"); 
	for(int i=0;i<=l;i++)
		printf("%d ",lroute[i]);
	printf("\n���� ª�� ��Ʈ:");	
	for(int i=0;i<=s;i++)
		printf("%d ",sroute[i]); 
}
