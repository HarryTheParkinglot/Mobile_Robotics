#include<stdio.h>
int tmp=1;
int pow(int a,int b){
	if(b==0){
		return tmp;
	}
	else{
		tmp*=a;
		pow(a,b-1);
	}
}
int main(void){
	int n,t;
	scanf("%d %d",&n,&t);
	printf("%d",pow(n,t));
	return 0;
}


