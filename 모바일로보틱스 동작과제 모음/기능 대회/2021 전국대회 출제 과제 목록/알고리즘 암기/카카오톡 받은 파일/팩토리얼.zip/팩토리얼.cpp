#include<stdio.h>
int tmp=1;
int fa(int a){
	if(a==0){
		return tmp;
	}
	else{
		tmp*=a;
		fa(a-1);
	}
}
int main(void){
	int n;
	scanf("%d",&n);
	printf("%d",fa(n));
	return 0;
}
