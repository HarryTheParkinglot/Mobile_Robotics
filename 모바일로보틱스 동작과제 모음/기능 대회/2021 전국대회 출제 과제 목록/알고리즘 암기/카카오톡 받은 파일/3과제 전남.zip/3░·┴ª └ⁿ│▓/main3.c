#include "Interface.h"
#include "math.h";

#define V3 while(!Cmd(0,19));
#define SV1 while(!Cmd(0,18));
#define cw		wa=0;
#define ar acf = cacf =0;
#define set pos[0] = pos[1] = pos[2] = 0;
#define wait SS(); while(SW3); while(!SW3);
#define rt bar_1 = bar_2 = bar_3 = bar_4 = bar_5 = sbar_1 = sbar_2 = 0;
#define lcs lcd_clear_screen(); 
int key = 0, key_puck = 0;
///////////////////

#define ab45    wa = 90; AB(0,0,4,223,5,210,50,0); cw
#define ab45_2  wa = 90; AB(0,0,4,243,5,223,50,0); cw

#define ab345(y) wa = 90; AB(3,197,4,230,5,208,50,y); cw
#define ab345_2(y) wa = 90; AB(3,212,4,243,5,223,50,y); cw
#define ab245(y) wa = 90; AB(2,223,4,230,5,208,50,y); cw
#define ab145(y) wa = 90; AB(1,128,4,230,5,208,50,y); cw

#define ab645(y) wa = 90; AB(6,233,4,230,5,208,50,y); cw
#define ab745(y) wa = 90; AB(7,231,4,230,5,208,50,y); cw
#define ab845(y) wa = 90; AB(8,117,4,230,5,208,50,y); cw

#define ab86 AB(0,0,6,221,8,104,50,0);
#define ab13 AB(0,0,1,122,3,186,50,0);

#define ab863(y) AB(3,122,6,221,8,104,50,y);
#define ab136(y) AB(6,221,1,122,3,186,50,y);

#define ab4(y) AB(4,220,0,0,0,0,0,y); cw
#define ab5(y) AB(5,134,0,0,0,0,0,y); cw
#define ab6(y) AB(6,89,0,0,0,0,0,y); cw
#define ab3(y) AB(3,115,0,0,0,0,0,y); cw
#define ab2(y) wa = 90; AB(2,230,0,0,0,0,0,y); cw
#define ab7(y) wa = 90; AB(7,235,0,0,0,0,0,y); cw
#define ab1(y) wa = 90; AB(1,170,0,0,0,0,0,y); cw
#define ab8(y) wa = 90; AB(8,127,0,0,0,0,0,y); cw
#define ab12(y)  AB(0,0,1,155,0,0,y,0); cw
#define ab82(y) AB(0,0,8,155,0,0,y,0); cw

#define ab1_40(y) wa = 90; AB(1,174,0,0,0,0,0,y); cw
#define ab8_40(y) wa = 90; AB(8,140,0,0,0,0,0,y); cw

#define ab1_45(y) wa = 90; AB(1,139,0,0,0,0,0,y); cw
#define ab8_45(y) wa = 90; AB(8,110,0,0,0,0,0,y); cw

#define ab865(y) AB(5,175,6,209,8,97,50,y);
#define ab134(y) AB(4,236,1,160,3,233,50,y);
#define ab34(y) AB(4,228,0,0,3,170,50,y);

#define CL(check, d, sp, ac) wa = -90, CBPsd(check,d,4,236,5,214,sp,ac), cw;
#define CR(check, d, sp, ac) wa = 90,  CBPsd(check,d,4,236,5,214,sp,ac), cw;

#define ab02(y) AB(0,200,0,0,0,0,0,y); cw
#define ab0(y) AB(0,238,0,0,0,0,0,y); cw

#define buz(y) LED_ON(3); _delay_ms(y); LED_OFF(3);
/////////////////////////////////////


//  0
//1   3 
//  2

int bgate,cgate,cpuck;

int nd=0,wd=0;

int depth = 0;

int goal[9] = {
	0, 0, 0,
	0, 0, 0,
	0, 0, 0
};
int ori[9] = {
	0, 0, 0,
	0, 0, 0,
	0, 0, 0
};
int link[9][4] = {
	{-1, -1, 3, 1},
	{-1, 0, 4, 2},
	{-1, 1, 5, -1},
	{0, -1, 6, 4},
	{1, 3, 7, 5},
	{2, 4, 8, -1},
	{3, -1, -1, 7},
	{4, 6, -1, 8},
	{5, 7, -1, -1}
};
int node[9] = { 0 };
int searching_path[32] = { 0 };
int path[32] = { 0 };
int path_len = 0;

int GetHeuristic(int *node) {
	int sum = 0;
	int match[9] = { 0 };

	for (int i = 0; i < 9; i++) {
		if (node[i] == goal[i])
			match[i] = 1;
	}

	for (int i = 0; i < 9; i++) {
		if (!node[i] || node[i] == goal[i])
			continue;

		for (int j = 0; j < 9; j++) {
			if (goal[j] == node[i] && !match[j]) {
				match[j] = 1;
				sum += (abs(i / 3 - j / 3) + abs(i % 3 - j % 3));
				break;
			}
		}
	}

	return sum;
}

void DfsPath(int pos, int len, int prevPos) {
	if (len > depth)
		return;

	if (!GetHeuristic(node)) {
		if (len < path_len)
		{
			for (int i = 0; i < len; i++)
				path[i] = searching_path[i];

			path_len = len;
		}
	}
	else {
		int next_pos = 0;
		//int ch = GetHeuristic(node);
		int heuristics[4] = { 999, 999, 999, 999 };

		for (int i = 0; i < 4; i++) {
			next_pos = link[pos][i];

			if (next_pos != prevPos
				&& next_pos >= 0
				&& searching_path[len - 1] != next_pos) {

				node[pos] = node[next_pos];
				node[next_pos] = 0;

				heuristics[i] = GetHeuristic(node);
				
				node[next_pos] = node[pos];
				node[pos] = 0;
			}
		}

		for (int h = 0; h < 36; h++) {
			for (int i = 0; i < 4; i++) {
				if (heuristics[i] == h) {
					next_pos = link[pos][i];

					node[pos] = node[next_pos];
					node[next_pos] = 0;

					searching_path[len] = next_pos;

					DfsPath(next_pos, len + 1, pos);
					if (path_len != 999)
						return;

					node[next_pos] = node[pos];
					node[pos] = 0;
				}
			}
		}
	}
}

int SearchPath() {
	int bp = 0;

	for (int i = 0; i < 9; i++) {
		node[i] = ori[i];
		if (!ori[i])
			bp = i;
	}
		
	path_len = 999;
	searching_path[0] = bp;

	DfsPath(bp, 1, -1);

	if (path_len != 999)
		return 1;

	return 0;
}

void MLC(){
	MoveLineCheck(0,10,0,0,10,120);
	MoveLineCheck(0,-20,0,0,10,120);

	MoveLineCheck(0,30,0,0,10,120);
	MoveLineCheck(0,-30,0,0,10,120);
}

void GoPos(int wp){ ///////////////////////////////////////////////////////////////////
	if(wp==0){
		CPsd(12,1,10,3,11,0,50,60);
		CPsd(10,1,102,5,11,0,50,0);
		Ot(20,-90,0,50,0);
		Axis(5,1,0,50,-60);

		nd=0;
	}
	else if(wp==3){
		CPsd(12,1,10,3,11,0,50,60);
		CPsd(10,1,50,5,11,0,50,0);
		Ot(20,-90,0,50,0);
		Axis(5,0,0,50,-60);

		nd=0;
	}
	else if(wp==6){
		ar
		ab1_40(50)

		Ot(22,-90,0,50,60);
		Axis(2,0,0,50,-60);

		nd=0;
	}
	else if(wp%3 && wp>3){
		CPsd(12,1,9,3,11,0,50,60);
		CPsd(10,1,9,5,11,0,50,0);
		Drift(8,35,-92,40,-50);

		ar
		ab45

		if(wp==4){
			Drift(0,20,20,50,60);
			wa=20;
			Axis(0,30,0,50,0);
			Ot(25,90,-20,40,0);
			cw
			Axis(-2,0,0,40,-50);

			nd=3;
		}
		else if(wp==5){
			Drift(0,20,20,50,60);
			wa=20;
			Axis(0,85,0,50,0);
			Ot(25,90,-20,40,0);
			cw
			Axis(-3,0,0,40,-50);

			nd=3;
		}
		else if(wp==7){
			Drift(0,20,-20,50,60);
			wa=-20;
			Axis(0,30,0,50,0);
			Ot(25,-90,22,40,0);
			cw
			Axis(3,0,0,40,-50);

			nd=3;
		}
		else if(wp==8){
			Drift(0,20,-20,50,60);
			wa=-20;
			Axis(0,87,0,50,0);
			Ot(25,-90,22,40,-50);

			cw

			nd=3;
		}
	}
	else{
		CPsd(12,1,10,3,11,0,50,60);
		CPsd(10,1,100,5,11,0,50,0);
		Drift(6,40,-90,40,-50);

		ar
		ab345(50);

		if(wp==1){
			CPsd(12,1,10,3,11,0,50,60);
			CPsd(10,1,40,5,11,0,50,0);
			Ot(25,-90,0,40,-50);

			nd=3;
		}
		else if(wp==2){
			CPsd(12,1,10,3,11,0,50,60);
			CPsd(10,1,94,5,11,0,50,0);
			Ot(25,-90,0,40,-50);

			nd=3;
		}
	}
}

int GetDir(int np, int wp){
	if(wp-np==-3) return 0;
	if(wp-np==-1) return 1;
	if(wp-np== 3) return 2;
	if(wp-np== 1) return 3;
}

void Dir(int nd,int wd){
	int dir=(wd-nd)*90;

	Axis(0,0,abs(dir)==270 ? dir/-3:dir,60,130);
}

void RMove(int np, int wp){
	wd=GetDir(np,wp);

	Dir(nd,wd);

	MLC();

	MoveLine(1,0,1000,40,50);
	Od2(0,25,180,40,-50,60,130);

	MLC();

	set
	MoveLine(2,0,1000,30,40);
	Axis(0,2,0,30,-40);

	Axis(0,-pos[1],0,40,150);

	nd=(wd+2)%4;
}

void back(int np){
	if(np==3){
		Dir(nd,2);

		MLC();

		ar
		ab8_40(50)

		CPsd(12,8,10,3,15,0,50,60);
		CPsd(10,8,35,5,15,0,50,0);
		Drift(-4,36,90,40,-50);

		Axis(-3,3,0,10,120);

		ar
		ab645(50)
	}
	else if(np==4){
		Dir(nd,1);

		MLC();

		Drift(-27,0,20,40,150);

		wa=20;
		Axis(0,40,0,50,60);
		Drift(-3,35,70,40,0);
		cw
	
		CPsd(12,8,10,3,15,0,50,60);
		CPsd(10,8,10,5,15,0,50,0);
		Drift(-4,36,90,40,-50);

		Axis(-3,3,0,10,120);

		ar
		ab645(50)
	}
	else{
		Dir(nd,1);

		MLC();

		Drift(-27,0,20,40,150);

		wa=20;
		Axis(0,95,0,50,60);
		Drift(-4,33,70,40,0);
		cw
	
		CPsd(12,8,10,3,15,0,50,60);
		CPsd(10,8,10,5,15,0,50,0);
		Drift(-4,36,90,40,-50);

		Axis(-3,3,0,10,120);

		ar
		ab645(50)
	}
}

void put(int wp){
	if(wp==3){
		ar ab345(50);

		CPsd(12,1,10,3,11,0,50,60);
		CPsd(10,1,15,5,11,0,50,0);
		Drift(0,30,-45,40,-50);

		Axis(0,15,0,20,130);

		Axis(0,-14,0,20,130);
		wa=-45;
		Drift(3,-20,25,40,50);
		wa=-20;
		CPsd(12,4,-10,3,20,0,50,0);
		CPsd(10,4,-10,5,20,0,50,0);
		CPsd(-5,4,-1000,3,20,23,50,0);
		Drift(0,-10,20,40,-50);
		cw

		ar ab345(50);
	}
	else if(wp==4){
		ar ab345(50);

		CPsd(12,1,9,3,11,0,50,60);
		CPsd(10,1,9,5,11,0,50,0);
		Drift(5,35,-90,40,-50);

		ar ab45(50);

		Drift(0,20,20,40,50);
		wa=20;
		Axis(0,10,0,40,0);
		Drift(0,15,25,40,-50);
		cw

		MoveLineCheck(0,0,1000,0,20,30);
		Axis(0,7,0,20,-30);

		Axis(0,-20,0,20,130);
		wa=45;

		Drift(0,-20,-25,40,50);

		wa=20;
		Avoid(4,15,15,20,-1000,50,0);
		Axis2(20,-12,40,50,50,-60);
		
		Drift(15,1,50,30,0);
		wa=-20;

		//Ot(-21,90,50,50,0);
	
		wa=-20;
		CPsd(12,4,-3,3,16,0,40,0);
		CPsd(10,4,-3,5,16,0,40,0);
		Drift(2,-10,20,30,-40);

		ar
		ab345(50)
	}
	else{
		ar ab345(50);

		CPsd(12,1,9,3,11,0,50,60);
		CPsd(10,1,9,5,11,0,50,0);
		Drift(5,35,-90,40,-50);

		ar ab45(50);

		Drift(0,20,20,40,50);
		wa=20;
		Axis(0,64,0,40,0);
		Drift(0,15,25,40,-50);
		cw

		MoveLineCheck(0,0,1000,0,20,30);
		Axis(0,6,0,20,-30);

		Axis(0,-20,0,20,130);
		wa=45;

		Drift(0,-20,-25,40,50);

		wa=20;
		Avoid(4,15,15,20,-1000,50,0);
		Axis2(20,-12,40,50,50,-60);
		
		Drift(15,1,50,30,0);
		wa=-20;

		//Ot(-21,90,50,50,0);
	
		wa=-20;
		CPsd(12,4,-5,3,16,0,40,0);
		CPsd(10,4,-5,5,16,0,40,0);
		Drift(2,-10,20,30,-40);

		ar
		ab345(50)
	}
}

int main(void)
{    
    Interface_init(); 
	
	LM629_HW_Reset();

	MCU_init();	   
	Sensor_init();
	sei();
	
	Motor_init();  
	_delay_ms(200);
	Camera_init();
	V3;
	TM(80);
	Setting(13);

	LED_ON(3);
	_delay_ms(100);
	LED_OFF(3);
	
	set
	
	while(1)
	{
		if(SW1) {

			key--;
			_delay_ms(70);
		}
		if(SW3) {

			key++;
			_delay_ms(70);
		}
		if(SW2) {
			lcd_clear_screen();
			switch(key) {

case 0:

cpuck=0;

SS();
SV1
V1();
V3

for(int i = 0;i<9;i++)
{
	if(!pro[i][0]) continue;
	if(abs(pro[i][1]-136)<20 && abs(pro[i][2]-169) < 20) cpuck = pro[i][0];
}

if(cpuck){
	Axis(0,0,-20,40,110);

	wa=-20;
	CPsd(12,4,-8,3,15,0,40,50);
	CPsd(10,4,-8,5,15,0,40,0);
	CPsd(4,4,-1000,3,15,30,40,0);
	Avoid(5,11,11,30,-1000,40,0);
	Drift(0,-13,20,35,-45);

	ar
	ab45

	Axis(0,-3,0,10,120);

	Drift(35,-1,90,40,150);

	Avoid(0,11,11,0,35,30,140);
}
else{
	CPsd(12,1,8,3,11,0,40,50);
	CPsd(10,1,8,5,11,0,40,0);
	CPsd(1,1,1000,3,11,30,40,0);
	Drift(1,39,-90,35,-45);
}

for(int i=0;i<3;i++){
	if(g_psd[1]>30){
		bgate=3;

		Axis(0,0,-20,40,110);

		wa=-20;
		CPsd(12,4,-10,3,15,0,40,50);
		CPsd(10,4,-10,5,15,0,40,0);
		CPsd(-5,4,-1000,3,15,30,40,0);
		Drift(0,-13,20,35,-45);
		break;
	}
	else if(g_psd[2]>30){
		bgate=2;
		
		Axis(0,0,-20,40,110);

		wa=-20;
		CPsd(12,4,-10,3,15,0,40,50);
		CPsd(10,4,-10,5,15,0,40,0);
		CPsd(-5,4,-1000,3,15,30,40,0);
		Drift(0,-13,20,35,-45);

		break;
	}
	else if(g_psd[3]>30){
		bgate=1;

		Axis(0,0,-20,40,110);

		wa=-20;
		Avoid(5,13,13,30,-1000,40,50);
		Drift(0,-13,20,35,-45);

		break;
	}
	else{
		CPsd(12,1,10,3,11,0,50,60);
		CPsd(10,1,26,5,11,0,50,0);
		Drift(6,35,-90,40,-50);
		
		ar
		ab45_2

		ar
		ab345_2(50)

		Axis(-1,0,0,10,120);

		Avoid(0,11,15,0,69,30,140);
	}
}

case 4:

bgate=2;

ar
ab345_2(40)

if(bgate==1){
	Axis(0,0,20,70,130);
	wa=20;

	Axis(0,19,0,40,50);
	Ot(26,90,90,35,0);
	Drift(-1,30,71,40,-50);
	cw
	
	CPsd(12,1,5,3,12,0,40,50);
	CPsd(10,1,5,5,12,0,40,0);
	Drift(4,36,-90,40,-50);

	ar
	ab345(50)
}
else {
	CPsd(12,1,7,3,12,0,40,50);
	CPsd(10,1,7,5,12,0,40,0);
	CPsd(1,1,1000,3,12,30,40,0);
	Drift(0,11,20,40,0);
	wa=20;

	Ot(26,90,90,35,0);
	Drift(-1,30,71,40,-50);
	cw
	
	if(bgate==2) {
		CPsd(12,1,15,3,12,0,40,50);
		CPsd(10,1,20,5,12,0,40,0);	
	}
	else {
		CPsd(12,1,30,3,12,0,40,50);
		CPsd(10,1,38,5,12,0,40,0);
	}
	Drift(4,40,-90,40,-50);

	ar
	ab345(50)
}

//////////////////////////////////////////////


ar
ab345(50)

Axis(0,5,0,10,120);

scan(0,3);

CPsd(12,1,10,3,11,0,60,70);
CPsd(10,1,105,5,11,0,60,0);
Drift(8,35,-90,50,-60);

ar
ab345(50)

scan(2,1);

CPsd(12,1,10,3,11,0,60,70);
CPsd(10,1,105,5,11,0,60,0);
Drift(8,35,-90,50,-60);

ar
ab345(50)

scan(8,5);

CPsd(12,1,10,3,11,0,60,70);
CPsd(10,1,105,5,11,0,60,0);
Drift(8,35,-90,50,-60);

ar
ab345(50)

Axis(5,0,0,10,120);

scan(6,7);

ar
ab345(50)

Axis(0,0,-20,40,110);

wa=-20;

Axis(0,115,0,50,60);
Drift(3,35,-70,40,-50);

Axis(3,3,0,10,120);

case 1:

ar
ab345(50)

CPsd(12,1,9,3,11,0,50,60);
CPsd(10,1,9,5,11,0,50,0);
Drift(6,35,-80,40,-50);

SS();
SV1
V1();
V3

for(int i = 0;i<9;i++)
{
	if(!pro[i][0]) continue;
	if(abs(pro[i][1]-97)<25 && abs(pro[i][2]-87) < 25) ori[4] = pro[i][0];
}

wa=10;

Drift(50,-5,80,40,150);

ar
ab345(50)

lcs
lcd(0,0,"%d  %d  %d",ori[0],ori[1],ori[2]);
lcd(1,0,"%d  %d  %d",ori[3],ori[4],ori[5]);
lcd(2,0,"%d  %d  %d",ori[6],ori[7],ori[8]);

wait

case 2:

if(key){
	bgate=3;
}

ar ab345(50);

CPsd(12,1,10,3,11,0,40,50);
CPsd(10,1,10,5,11,0,40,0);
Drift(3,30,-91,40,0);
Drift(-30,3,-92,40,-50);

SS();
SV1
V1();
V3

for(int i = 0;i<9;i++)
{
	if(!pro[i][0]) continue;
	if(abs(pro[i][1]-95)<15 && abs(pro[i][2]-14) < 15) goal[2] = pro[i][0];
	if(abs(pro[i][1]-146)<15 && abs(pro[i][2]-13) < 15) goal[1] = pro[i][0];
	if(abs(pro[i][1]-196)<15 && abs(pro[i][2]-16) < 15) goal[0] = pro[i][0];
}

lcs
lcd(0,0,"%d  %d  %d",goal[0],goal[1],goal[2]);

Drift(-3,30,90,40,150);

ar ab45(50);

Drift(1,43,-80,40,150);
wa=20;

SS();
SV1
V1();
V3

for(int i = 0;i<9;i++)
{
	if(!pro[i][0]) continue;
	if(abs(pro[i][1]-207)<15 && abs(pro[i][2]-35) < 15) goal[3] = pro[i][0];
}

Axis(0,0,20,40,110);

SS();
SV1
V1();
V3

for(int i = 0;i<9;i++)
{
	if(!pro[i][0]) continue;
	if(abs(pro[i][1]-69)<15 && abs(pro[i][2]-19) < 15) goal[5] = pro[i][0];
}

SS();
SV1
V1();
V3

if(bgate==3){
	for(int i = 0;i<9;i++)
	{
		if(!pro[i][0]) continue;
		if(abs(pro[i][1]-195)<15 && abs(pro[i][2]-31) < 15) goal[4] = pro[i][0];
	}
}
else if(bgate==1){
	for(int i = 0;i<9;i++)
	{
		if(!pro[i][0]) continue;
		if(abs(pro[i][1]-158)<15 && abs(pro[i][2]-27) < 15) goal[4] = pro[i][0];
	}
}


lcs
lcd(0,0,"%d  %d  %d",goal[3],goal[4],goal[5]);

Drift(40,-8,60,40,150);

ar
ab45

Axis(0,0,-20,40,110);
wa=-20;

Axis(0,118,0,50,60);
Drift(3,33,-70,50,-60);
cw

ar ab13(50);

SS();
SV1
V1();
V3

for(int i = 0;i<9;i++)
{
	if(!pro[i][0]) continue;
	if(abs(pro[i][1]-70)<15 && abs(pro[i][2]-32) < 15) goal[8] = pro[i][0];
	if(abs(pro[i][1]-136)<15 && abs(pro[i][2]-32) < 15) goal[7] = pro[i][0];
	if(abs(pro[i][1]-203)<15 && abs(pro[i][2]-32) < 15) goal[6] = pro[i][0];
}

lcs
lcd(0,0,"%d  %d  %d",goal[6],goal[7],goal[8]);


CPsd(12,1,7,3,11,0,40,50);
CPsd(10,1,7,5,11,0,40,0);
Drift(5,35,-90,35,-45);

ar ab345(50)

Axis(0,0,-20,70,130);
wa=-20;

Axis(0,123,0,50,60);
Drift(3,31,-70,40,-50);

Axis(4,4,0,10,120);

ar
ab345(50)

lcs
lcd(0,0,"%d  %d  %d",goal[0],goal[1],goal[2]);
lcd(0,0,"%d  %d  %d",goal[3],goal[4],goal[5]);
lcd(0,0,"%d  %d  %d",goal[6],goal[7],goal[8]);

wait

case -1:

ar
ab345(50)

SS();

for (int i = 6; i <= 32; i++) {
	depth = i;
	if (SearchPath()) {
		buz(100);
		
		GoPos(path[0]);
		
		for (int i = 1; i < path_len; i++){
			RMove(path[i-1],path[i]);
		}
		back(path[path_len-1]);
		break;
	}	
}		

case-2:

ar
ab645(50)

if(key){
	bgate=3;
}

if(bgate==1){
	Drift(3,45,-90,40,150);

	Drift(-1,50,70,40,150);
}
else{
	CPsd(12,8,10,3,15,0,50,60);
	CPsd(10,8,10,5,15,0,50,0);
	CPsd(8,8,1000,3,15,30,50,0);
	
	Drift(3,41,-90,40,-50);

	Drift(-1,50,70,40,150);
}

wa=-20;
CPsd(12,4,-10,3,13,0,50,60);
CPsd(10,4,-10,5,15,0,50,0);
CPsd(-5,4,-1000,3,15,30,50,0);
Drift(3,-13,20,40,-50);
cw

case -3:

ar
ab345(50)

Drift(1,30,-20,40,150);

wa=-20;
if(T(101,3)){ /////////////////////////////////////00000000000000000000000
	Drift(2,44,-70,35,145);
	cw

	CPsd(12,1,8,3,11,0,40,50);
	CPsd(10,1,8,5,11,0,40,0);
	CPsd(1,1,1000,3,11,30,40,0);
	Drift(2,38,-90,35,0);

	CPsd(12,1,8,3,11,0,40,50);
	CPsd(10,1,8,5,11,0,40,0);
	CPsd(1,1,1000,3,11,30,40,0);
	Drift(2,33,-90,35,0);

	CPsd(12,1,10,3,11,0,40,50);
	CPsd(10,1,20,5,11,0,40,0);
	Drift(4,40,-90,35,-45);
}
else{
	Drift(2,44,-70,35,145);
	cw

	CPsd(12,1,8,3,11,0,40,50);
	CPsd(10,1,8,5,11,0,40,0);
	CPsd(1,1,1000,3,11,30,40,0);
	
	if(T(101,3)){ ///////////////////////////////////2222222222222222222222222222222
		Axis(0,40,0,40,0);

		CPsd(12,1,8,3,11,0,40,0);
		CPsd(10,1,8,5,11,0,40,0);
		CPsd(1,1,1000,3,11,30,40,0);
		Drift(2,35,-90,35,0);

		CPsd(12,1,10,3,11,0,40,50);
		CPsd(10,1,25,5,11,0,40,0);
		Drift(2,40,-90,35,0);

		CPsd(12,1,10,3,11,0,50,60);
		CPsd(10,1,90,5,11,0,50,0);
		Drift(2,40,-90,40,-50);
	}
	else{
		Od2(0,6,-45,35,-45,60,130);

		if(T(101,3)){ /////////////////////////////////////////////////////////////1
			wa=-45;
			Drift(1,29,-45,30,140);
			cw

			CPsd(12,1,8,3,11,0,40,50);
			CPsd(10,1,8,5,11,0,40,0);
			CPsd(1,1,1000,3,11,30,40,0);
			Drift(2,33,-90,35,0);

			CPsd(12,1,10,3,11,0,40,50);
			CPsd(10,1,20,5,11,0,40,0);
			Drift(5,40,-91,35,-45);
		}
		else{ /////////////////////////////////////////////////////////3
			Axis(0,0,75,40,10);
			wa=30;
			Od2(0,29,60,30,140,40,-10);
			cw

			CPsd(12,1,8,3,11,0,40,50);
			CPsd(10,1,8,5,11,0,40,0);
			CPsd(1,1,1000,3,11,30,40,0);
			Drift(2,33,-90,35,0);

			CPsd(12,1,10,3,11,0,40,50);
			CPsd(10,1,20,5,11,0,40,0);
			Drift(2,40,-90,35,0);

			CPsd(12,1,10,3,11,0,50,60);
			CPsd(10,1,105,5,11,0,50,0);
			Drift(2,40,-90,40,0);

			CPsd(12,1,10,3,11,0,50,60);
			CPsd(10,1,95,5,11,0,50,0);
			Drift(2,40,-90,40,-50);
		}
	}
}

Axis(3,5,0,10,120);

ar
ab345_2(40)

wait

if(bgate==1){
	Axis(0,0,20,70,130);
	wa=20;

	Axis(0,19,0,40,50);
	Ot(26,90,90,35,0);
	Drift(-1,30,71,40,-50);
	cw
	
	CPsd(12,1,5,3,12,0,40,50);
	CPsd(10,1,5,5,12,0,40,0);
	Drift(4,36,-90,40,-50);

	ar
	ab345(50)
}
else {
	CPsd(12,1,7,3,12,0,40,50);
	CPsd(10,1,7,5,12,0,40,0);
	CPsd(1,1,1000,3,12,30,40,0);
	Drift(0,11,20,40,0);
	wa=20;

	Ot(26,90,90,35,0);
	Drift(-1,30,71,40,-50);
	cw
	
	if(bgate==2) {
		CPsd(12,1,15,3,12,0,40,50);
		CPsd(10,1,20,5,12,0,40,0);	
	}
	else {
		CPsd(12,1,30,3,12,0,40,50);
		CPsd(10,1,38,5,12,0,40,0);
	}
	Drift(4,40,-90,40,-50);

	ar
	ab345(50)
}

put(path[path_len-1]);

case -4:
if(key){
bgate=3;
}

ar
ab345(50)

if(bgate==1){
	Drift(47,0,70,40,150);

	wa=-20;
	Drift(-55,1,-90,40,150);

	Drift(-43,1,-70,40,150);
	cw
}
else if(bgate==2){
	Od2(79,-2,70,50,160,110,130);

	wa=-20;
	Drift(-58,0,-50,40,150);
	
	wa=20;
	CPsd(12,5,-10,3,11,0,50,60);
	CPsd(10,5,-10,5,11,0,50,0);
	CPsd(5,5,-1000,3,11,30,50,0);
	Axis(0,-39,0,50,-60);

	goto B2;
}
else{
	Od2(30,0,70,50,160,110,130);
	
	wa=-20;
	CPsd(12,4,-10,3,15,0,50,60);
	CPsd(10,4,-10,5,15,0,50,0);
	CPsd(4,4,-1000,3,15,30,50,0);
	Axis(0,-40,0,50,-60);

	Drift(-50,1,-70,40,150);
	cw
	
	Od2(-35,1,-70,50,160,130,160);
	
	wa=20;
	CPsd(12,3,-10,3,20,0,50,60);
	CPsd(10,3,-10,5,20,0,50,0);
	CPsd(-4,3,-1000,3,20,30,50,0);
	Drift(0,-13,-20,40,-50);
}

Axis(3,3,0,10,120);

ar
ab345(50)

Axis(0,0,-20,40,110);

wa=-20;

Axis(0,30,0,40,50);

Drift(3,42,-70,35,0);
cw

CPsd(12,1,8,3,11,0,40,50);
CPsd(10,1,8,5,11,0,40,0);
CPsd(1,1,1000,3,11,30,40,0);
Axis(0,38,0,40,-50);

B2 :

	
///////////////////
SS();
LED_ON(0);
LED_ON(1);
LED_ON(2);
LED_ON(3);
_delay_ms(100);
LED_OFF(3);
LED_OFF(0);
LED_OFF(1);
LED_OFF(2);
while(!SW1);
while(SW1);
_delay_ms(70);
break;

			}
		}

			if (key) {
				lcd(0,0, "%03d %03d %03d %03d %03d", g_psd[2], g_psd[1], g_psd[0], g_psd[8], g_psd[7]);
				lcd(1,0, "%03d %03d     %03d %03d", g_psd[3], g_psd[4], g_psd[5], g_psd[6]);
			}
			else {
				lcd(0,0, "%03d %03d %03d %03d %03d", psd[2], psd[1], psd[0], psd[8], psd[7]);
				lcd(1,0, "%03d %03d     %03d %03d", psd[3], psd[4], psd[5], psd[6]);
			}

			key_puck = abs(key);
			lcd(2,0,"C%d X%3d Y%3d S%2d",key_puck,Cmd(key_puck, 102), Cmd(key_puck, 103), Cmd(key_puck, 104));
			lcd(3,0,"%d%d%d|%d%d %d%d%d|%d%d ",IR_1,IR_2,IR_3,IND_1,IND_2, bar_1, bar_2, bar_3, sbar_1, sbar_2, key_puck);
			lcd(3,16, "K:%02d", key);
	}   		
}

void scan(int p1,int p2){
	SS();
	SV1
	V1();
	V3

	for(int i = 0;i<9;i++)
	{
		if(!pro[i][0]) continue;
		if(abs(pro[i][1]-187)<25 && abs(pro[i][2]-33) < 25) ori[p1] = pro[i][0];
		if(abs(pro[i][1]-227)<25 && abs(pro[i][2]-87) < 25) ori[p2] = pro[i][0];
	}

	lcs lcd(1,0,"%d %d",ori[p1],ori[p2]);
}

