#include "Motor.h"
#include "Move.h"
#include "Sensor.h"
#include "Omni.h"
#include <String.h>

#define SLA             0x07

#define SW1				(~PINB&0x10)
#define SW2				(~PINB&0x20)
#define SW3				(~PINB&0x40)
#define SW4				(~PINB&0x80)

#define LED_ON(x)		(PORTB |= 1<<x)
#define LED_OFF(x)		(PORTB &=~1<<x)

#define lcd(a,b,...)	sprintf(buf,__VA_ARGS__); LCD(a,b,buf);

#define cha				(M_PI/180)

void MCU_init(void);
void Interface_init(void);
char getchar1(void);
void putchar1(char data);

void lcd_write_data(unsigned char data);
void LCD(unsigned char Y_line, unsigned char X_line,char *string);
void lcd_clear_screen(void);

volatile extern unsigned char rx1_flg, rx1_buff;
volatile extern double sgx,sgy,sgz,sga;
volatile extern int code,co[10];
volatile extern char buf[];																																																																																																																																																																																																																																																																																																																																							

volatile int pc;
