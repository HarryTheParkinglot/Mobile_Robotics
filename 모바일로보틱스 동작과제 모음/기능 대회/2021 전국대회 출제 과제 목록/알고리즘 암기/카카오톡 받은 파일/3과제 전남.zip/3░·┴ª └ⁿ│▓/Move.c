#include "Sensor.h"
#include "Interface.h"

void StartMotion(void)
{
    WriteCommand(MOTOR0, STT);
    WriteCommand(MOTOR1, STT);
    WriteCommand(MOTOR2, STT);
}

volatile int IR_1, IR_2, IR_3, IR_4, IR_5, IND_1, IND_2, pro[9][5], tot;
volatile double gsp[4], gsp2[4], msp[4];

// Function  : ��� ������ ����� �����Ѵ�.
// Parameter : ����
// Return    : ����

void IR(void) {
	IR_1 = (PINE&4)? 0:1;
	IR_2 = (PINE&8)? 0:1;
	IR_3 = (PINE&16)? 0:1;	
	IR_4 = (PIND&16)? 0:1;
	IR_5 = (PIND&64)? 0:1;

	IND_1 = (~PING&8)? 1:0;
	IND_2 = (~PING&16)? 1:0;	
}

int LF(int max, int min, int val) {
	if(val>max)	return max;
	if(val<min)	return min;
	
	return val;
}

void SS() {
	speed(0,0,0,0);
}

#define ginit(sname)	oc = tot = 0;	for(int i = 0; i < 4; i++) gsp[i] = msp[i] = 0;	lcd(0, 7, "%13s", sname);
#define LE				lcd(0, 0, "%d", tot); oc = gtc = sgx = sgy = sgz = sga = 0;
#define VLE				lcd(0, 0, "%d", tot); oc = gtc = 0;

void Axis(int x, int y, int z, int sp, int ac) {
	ginit("Axis");

	Omni(x, y, 0, 0, sp, ac, msp, 0);

	if(x && y)
		sp *= (double) sp / hypot(msp[0], msp[1]);

	tot = Omni(x, y, z, 0, sp, ac, msp, 0);

	while(1) {
		OmniSet(tot, ac, msp, gsp, 0);
		
		speed(gsp[1], gsp[0], gsp[2], wa);
		if(!oc)	oc = 1;
		if(oc > tot)	{ LE return; }
	}
}

int MovePsd(int check, int ps, int x, int y, int z, int pc, int sp, int ac) {
	ginit("MovePsd");
	
	Omni(x,y,0,0,sp,ac,msp,0);
	
	if(x&&y)
		sp*=(double)sp/hypot(msp[0],msp[1]);
		
	tot = Omni(x,y,z,0,sp,ac,msp,0);
	
	while(1) {
		OmniSet(tot,ac,msp,gsp,0);
		
		if(g_psd[ps] != 9) {
			if(check == 0 && g_psd[ps] <= pc) {LE return 2;}
			if(check == 1 && g_psd[ps] >= pc) {LE return 1;}
		}

		speed(gsp[1],gsp[0],gsp[2],wa);
		if(!oc)	oc=1;
		if(oc>tot)	{LE return 0;}
	}
}

void Axis2(int x, int y, int xsp, int xac, int ysp, int yac) {
	ginit("Axis2");
	
	int cnt1 = Omni(x,0,0,0,xsp,xac,msp,10);
	int cnt2 = Omni(0,y,0,0,ysp,yac,msp,11);
	
	while(1) {
		OmniSet(cnt1,xac,msp,gsp,10);
		OmniSet(cnt2,yac,msp,gsp,11);
		
		speed(gsp[1],gsp[0],0,wa);
		if(!oc)	oc=1;
		if(oc>cnt1&&oc>cnt2)	{LE return;}
	}
}

void Drift(int x, int y, int z, int sp, int ac) {
	ginit("Drift");
	
	double add = 0, n_a = 0;
	
	Omni(x,y,z,0,sp,ac,msp,0);
	
	sp*=fabs(sp/hypot(msp[0],msp[1]));
	tot = Omni(x,y,z,0,sp,ac,msp,0);
	
	while(1) {
		OmniSet(tot,ac,msp,gsp,0);
		
		if(!gtc) {
			gtc = 1;
			add += gsp[2] * 1.747/100;
			n_a = -add/cha/100;
		}
		
		speed(gsp[1],gsp[0],gsp[2],wa+n_a);
		if(!oc)	oc=1;
		if(oc>tot)	{LE return;}
	}
}

void Od2(int x, int y, int z, int sp, int ac, int zsp, int zac) {
	ginit("Od2");
	
	double add = 0, n_a = 0;
	
	Omni(x,y,0,0,sp,ac,msp,2);
	
	if(x&&y)
		sp*=(double)sp/hypot(msp[0],msp[1]);
		
	int cnt2 = Omni(0,0,z,0,zsp,zac,msp,12);
	int cnt1 = Omni(x,y,0,0,sp,ac,msp,2);
	
	while(1) {
		if(z) OmniSet(cnt2,zac,msp,gsp,12);
		
		OmniSet(cnt1,ac,msp,gsp,2);
		
		if(!gtc) {
			gtc = 1;
			add += gsp[2] * 1.747/100;
			n_a = -add/cha/100;
		}

		speed(gsp[1],gsp[0],gsp[2],wa+n_a);
		if(!oc)	oc=1;
		if(oc>cnt1 && oc>cnt2)	{LE return;}
	}
}

void Ot(int r, int z, int ang, int sp, int ac) {
	ginit("Ot");
	
	double add = 0, n_a = 0;
	double add2 = 0, n_a2 = 0;
	double y = M_PI * r * abs(z)/180;
	
	Omni(0,y,z,ang,sp,ac,msp,0);
	
	sp*=fabs(sp/msp[1]);
	tot = Omni(0,y,z,ang,sp,ac,msp,0);
	
	while(1) {
		OmniSet(tot,ac,msp,gsp,0);
		
		if(!gtc) {
			gtc = 1;
			add += gsp[2] * 1.747/100;
			n_a = add/cha/100;
			add2 += gsp[3] * 1.747/100;
			n_a2 = -add2/cha/100;
		}
		
		speed(gsp[1],0,gsp[3],wa+n_a+n_a2);
		if(!oc)	oc=1;
		if(oc>tot)	{LE return;}
	}
}

void CPsd(int check, int ps, int cm ,int v, int pm, int pc, int sp, int ac) {
	ginit("CPsd");
	
	int x,y,z,d = ((ps*40+wa)%360 < 180)? 1: -1;
	
	tot = Omni(0,cm,0,0,sp,ac,msp,0);
	
	while(1) {
		OmniSet(tot,ac,msp,gsp,0);
		
		if(abs(check)<9) {
			if(g_psd[abs(check)] != 9) {
				if(check <= 0 && g_psd[abs(check)] <= pc) {LE return;}
				if(check > 0 && g_psd[abs(check)] >= pc) {
					if(check == ps) {speed(gsp[1],0,0,wa); _delay_us(10);}
					
					LE return;
				}
			}
		}

		if(check == 13 && IR_2) {LE return;}
		if(check == 14 && IND_1) {LE return;}

		x = z = (g_psd[ps] - pm);
		
		if(abs(z) >= 5)	z = LF(v*5,-v*5,z);
		if(cm<0)	z*=-1;
		if(check == 12)	x*=4, z=0;

		x/=2;
		x = LF(sp,-sp,x);

		speed(gsp[1],-x*d,-z*v*d,wa);
		if(!oc) oc=1;
		if(oc>tot)	{LE return;}
	}
}

int CBPsd(int check, int cm, int xp, int xm, int zp, int zm,int ps , int pm,int sp, int ac) {
	ginit("CBPsd");
	
	int x=0,y=0,z=0,xbo=1,zbo=1;
	int ap = xp+zp; if(xp&&zp) ap/=2;
	
	if((ap*40+wa)>180) xbo*=-1;
	if((ap*40+wa)>180)	zbo = (xbo<0)? 1: -1;
	else				zbo = (xbo<0)? -1: 1;
	
	tot = Omni(0,cm,0,0,sp,ac,msp,0);
	acf = 0;
	
	while(1) {
		if(check == 13 && IR_2) {LE return;}
		if(check == 14 && IND_1) {LE return ;}
		if(check == 15) {
			if(IR_2) {LE return 0;}
			if(IND_1) {LE return 1;}
		}
		if(check == 10 && pm && g_psd[ps] <= pm) {LE return ;}

		OmniSet(tot,ac,msp,gsp,0);

		x = (psd[xp] - xm) * xbo;
		x /= 4;
		z = (psd[xp] - psd[zp] - xm + zm) * zbo;

		speed(gsp[1],x*acf,z*acf,wa);
		if(!oc)	oc=1;
		if(oc>tot)	{LE return;}
	}
}

int linehandle(int sel, int lines) {
	int hd[3][6] = {
		{0,100,50,0,-50,-100},
		{75,0,-75,-100,-100,-120},
		{-75,120,120,100,75,0}
	};

	return (int)(hd[sel][lines]) * 0.25;
}

int linestatus(void) {
	int lines;
	
	if(IR_1 == 0 && IR_2 == 0 && IR_3 == 0) lines = 0;
	if(IR_1 == 1 && IR_2 == 0 && IR_3 == 0) lines = 1;
	if(IR_1 == 1 && IR_2 == 1 && IR_3 == 0) lines = 2;
	if(IR_1 == 0 && IR_2 == 1 && IR_3 == 0) lines = 3;
	if(IR_1 == 0 && IR_2 == 1 && IR_3 == 1) lines = 4;
	if(IR_1 == 0 && IR_2 == 0 && IR_3 == 1) lines = 5;
	if(IR_1 == 1 && IR_2 == 1 && IR_3 == 1) lines = 10;
	
	return lines;
}

int MoveLine(int check, int sel, int cm, int sp, int ac) {
	ginit("MoveLine");
	
	int c = 0, lines = 0;
	
	tot = Omni(0, cm, 0,0, sp, ac, msp, 0);
	
	while(1) {
		OmniSet(tot, ac, msp, gsp, 0);
		
		lines = linestatus();
		
		if(lines != 6) c = linehandle(sel,lines);
		else c = 0;

		if(check == 1 && lines == 10) {LE return 1;}
		if(check == 0 && lines == 0) {LE return 1;}
		if(check == 2 && IR_4 && IR_5) {LE return 1;}

		speed(gsp[1], 0, -c, wa);
		if(!oc)	oc = 1;
		if(oc > tot)	{LE return 0;}
	}
}

int MoveLineCheck(int check, int x, int y, double z, int sp, int ac) {
	ginit("MoveLineCheck");
	
	Omni(x, y, 0, 0, sp, ac, msp, 0);
	
	if(x && y)
		sp *= (double)sp/hypot(msp[0],msp[1]);
		
	tot = Omni(x, y, z, 0, sp, ac, msp, 0);
	
	while(1) {
		if(check == 0 && IR_2)	{LE return 1;}
		if(check == 1 && IND_1)	{LE return 1;}
		if(check == 2) {
			if(IR_1) {LE return 1;}
			if(IR_3) {LE return 2;}
		}
		if(check == 4) {
			if(IR_2) {LE return 0;}
			if(IND_1) {LE return 1;}
		}
		if(check ==5 && !IR_1){LE return 1;}

		OmniSet(tot, ac, msp, gsp, 0);
		
		speed(gsp[1], gsp[0], gsp[2], wa);
		if(oc == 0)			oc = 1;
		if(oc > tot)	{LE return 0;}
	}
}

void AB(int yp, int ym, int xp, int xm, int zp,int zm, int xsp, int ysp) {
	ginit("AB");
	
	int x= 0, y= 0 ,z = 0,xbo=1,ybo=1,zbo=1;
	int xra = 0,yra=0;
	int ap = xp+zp; if(xp&&zp)	ap/=2;
	int ya = (abs(yp*40-360) > abs(yp*40))? yp*40: yp*40-360;
	
	if((ap*40+wa) > 180)	xbo *= -1;
	if(abs(ya+wa) < 90)		ybo *= -1;
	if((ap*40+wa) > 180)	zbo = (xbo<0)? 1: -1;
	else					zbo = (xbo<0)? -1: 1;

	for(double i =0; i<=100; i+=0.1) {
		if(200 / i <= xsp) {
			xra = i; break;
		}
	}

	for(double i =0; i<=100; i+=0.1) {
		if(200 / i <= ysp) {
			yra = i; break;
		}
	}

	while(1){
		if(ym) {
			y = (psd[yp] - ym) * ybo; 
			y /= yra;
		}

		if(xm) {
			x = (psd[xp] - xm) * xbo;
			x /= xra;
		}

		if(zm) {
			z = (psd[xp] - psd[zp] - xm + zm) * zbo * 1.2;
		}
		
		x = LF(50,-50,x);
		y = LF(60,-60,y);
		z = LF(60,-60,z);

		speed(y*cacf,x*acf,z*acf,wa);
		if(!oc)	oc=1;
		if(abs(z) < 2 && abs(x)<2 && abs(y)< 2) {LE return;}
		if(oc>500) {LE return;}
	}
}

void Avoid(int ps,int pm, int pm2, int dis, int y, int sp, int ac) {
	ginit("Avoid");
	
	int zig = 0, l = (ps+1)%9, r = (ps+8)%9, d=1;
	
	if(y<0)	d*=-1;
	
	tot = Omni(0,y,0,0,sp,ac,msp,0);
	
	while(1) {
		OmniSet(tot,ac,msp,gsp,0);
		
		zig = 0;
		
		if(g_psd[l] < pm && g_psd[l] != 9) zig += (g_psd[l] - pm) * 3.5;
		if(g_psd[r] < pm2 && g_psd[r] != 9) zig += (g_psd[r] - pm2) * -3.5;
		if(g_psd[ps] <= dis && g_psd[ps] != 9) {LE return;}

		speed(gsp[1],-zig*d,0,wa);
		if(!oc)	oc=1;
		if(oc>tot)	{LE return;}
	}
}

int T(int data, int ci) {
	int puck[5], col =0, col2= 0, max = 0, min = 255;
	
	for(int i = 1; i <= ci; i++) {
		puck[i] = Cmd(i,abs(data));
		
		if(puck[i] > max) max = puck[i], col = i;
		if(puck[i] < min && puck[i]) min = puck[i], col2 = i;
	}
	
	return (data>0)? col: col2;
}

void TB(int col, int zp, int xp, int yp) {
	ginit("TB");
	
	int x =0, y =0 , z=0;
	int xpp = 0, zpp = 0, ypp = 0;
	
	pc = 0;

	while(1) {
		xpp = zpp = Cmd(col,102);
		ypp = Cmd(col,103);
		
		while(!xpp && !ypp) {
			SS();
			
			xpp =  Cmd(col,102);
			ypp = Cmd(col,103);
			
			if(!pc) {
				pc = 1;
			}
			if(pc > 350) {
				SS();
				return;
			}
			if(xpp) {
				acf = cacf = 0;
			}
		}

		if(xp)	x = (xpp-xp) *0.8;
		if(zp)	z = (zpp-zp) *0.6;
		if(yp)	y = (yp-ypp);

		y = LF(55,-55,y);
		x = LF(30,-30,x);
		z = LF(50,-50,z);
		
		speed(y*0.8*cacf,x*0.8*acf,z*acf,wa);
		if(!oc)	oc=1;
		if(abs(y)<=1&&abs(x)<=0&&abs(z)<=0) {LE return;}
		if(oc>350) {LE return;}
	}
}

void TB2(int col, int xp, int yp) {
	ginit("TB2");
	
	int l = 0, g= 0 , c= 0;
	int xpp = 0, xpp2 = 0, ypp = 0;

	xpp =  Cmd(col,102);
	xp += pos[2];
	xp += (xp-xpp)*((xp-xpp)/600 + 0.24);
	pc = 0;

	while(1) {
		xpp =  Cmd(col,102);
		ypp = Cmd(col,103);
		
		while(!xpp && !ypp) {
			SS();
			
			xpp =  Cmd(col,102);
			ypp = Cmd(col,103);
			
			if(!pc) {
				pc = 1;
			}
			if(pc > 350) {
				SS();
				return;
			}
			if(xpp) {
				acf = cacf = 0;
			}
		}

		if(xp)	c = (xpp-xp) *0.8;
		if(yp)	l = (yp-ypp);

		l = LF(60,-60,l);
		c = LF(50,-50,c);

		speed(l*0.8*cacf,0,c*acf,wa+pos[2]);
		if(!oc)	oc=1;
		if(abs(l)<=1&&abs(g)<=0&&abs(c)<=0) {LE return;}
		if(oc>350) {LE return;}
	}
}

void TM(unsigned char wm) {
	unsigned char buff =0 ;
	
	while(1) {
		putchar1(17);
		putchar1(wm);
		while(!rx1_flg);
		buff=getchar1();
		if(buff)break;
	}
}

int V1(void) {
	for(int i=0; i<9; i++) {
		for(int j=0; j<5; j++) {
			pro[i][j] = 0;
		}
	}

	int str[200], am;
	
	while(1) {
		gtc = 200;
		rx1_flg = 0;
		while(!rx1_flg) if(!gtc) return 0; // 2�� ��� ����x 

		if(getchar1() == 'V') {
			rx1_flg = 0;
			while(!rx1_flg);
			
			am = getchar1() - '0';

			for(int i = 0; i < am*15; i++) {
				rx1_flg = 0;
				while(!rx1_flg);
				str[i] = getchar1() - '0';
			}
			
			break;
		}
	}

	for(int i = 0; i < am; i++) {
		pro[i][0] = str[i*15+1]; //col
		pro[i][1] = str[i*15+3]*100 + str[i*15+4]*10 + str[i*15+5]; // x len
		pro[i][2] = str[i*15+6  ]*100 + str[i*15+7]*10 + str[i*15+8]; // y len
		pro[i][3] = str[i*15+9]*100 + str[i*15+10]*10 + str[i*15+11]; // x size
		pro[i][4] = str[i*15+12]*100 + str[i*15+13]*10 + str[i*15+14]; // y size
	}

	VLE return 1;
}
