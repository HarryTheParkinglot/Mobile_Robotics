#include "Motor.h"
#include <stdio.h>

volatile extern int IR_1, IR_2, IR_3, IR_4, IR_5, IND_1, IND_2, pro[9][5], tot;
volatile extern double gsp[],gsp2[], msp[];

volatile extern int MCV[10][3],mcnt;

void StartMotion(void);

void IR(void);

int LF(int max, int min, int val);

void SS();

void Axis(int x, int y, int z, int sp, int ac);

void Axis2(int x, int y, int xsp, int xac, int ysp, int yac);

int MovePsd(int check, int ps, int x, int y, int z, int pc, int sp, int ac);

void Drift(int x, int y, int z, int sp, int ac);

void Od2(int x, int y, int z, int sp, int ac, int zsp, int zac);

void Ot(int r, int z, int ang, int sp, int ac);

void CPsd(int check, int ps, int cm ,int v, int pm, int pc, int sp, int ac);

int CBPsd(int check, int cm, int xp, int xm, int zp, int zm,int ps , int pm,int sp, int ac);

int linehandle(int select, int lines);

int linestatus(void);

int MoveLine(int check, int sel, int cm, int sp, int ac);

int MoveLineCheck(int check, int x, int y, double z, int sp, int ac);

void AB(int yp, int ym, int xp, int xm, int zp,int zm, int xsp, int ysp);

void Avoid(int ps,int pm, int pm2, int dis, int y, int sp, int ac);

int T(int data, int ci);

void TB(int col, int zp, int xp, int yp);

void TB2(int col, int xp, int yp);

void TM(unsigned char wm);

int V1(void);
