#include <avr/interrupt.h>
#include <math.h>

int oc, wa;
double acf,cacf;

int ba1, bar_1;
int ba2, bar_2;
int ba3, bar_3;
int ba4, bar_4;
int ba5, bar_5;

int sba1, sbar_1;
int sba2, sbar_2;

volatile extern unsigned int gtc;

int Omni(int x, int y, int z, int ang, int sp, int ac, double *msp, int sel);

void OmniSet(int tot, int ac, volatile double *msp, volatile double *asp, int sel);
