#include<stdio.h>
void oubak(int a){
	if(a!=1){
		if(a%2==0){
			a/=2;
			printf("%d\n",a);
			oubak(a);
		}
		else{
			a=3*a+1;
			printf("%d\n",a);
			oubak(a);
		}
	}
}
int main(void){
	int n;
	scanf("%d",&n);
	oubak(n);
	return 0;
}

