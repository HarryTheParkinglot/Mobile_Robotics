/************************************************************************************************************/
/*                                                                                                          */
/*                                              MobileRobot.c                                               */
/*                                                                                                          */
/*                                                                                       2020. 1. 1.        */
/************************************************************************************************************/
#include "Interface.h"


#define cw wa = 0;
#define ar acf =cacf= 0;
#define set pos[0] = pos[1] = pos[2] = 0; gyro = rearGyro = 0;

#define V3 while(!Cmd(0,19));
#define SV1 while(!Cmd(0,18));
#define reset bar_1 = bar_2 = bar_3 = bar_4 = bar_5 = sbar_1 = sbar_2= 0;
#define wait if(key) {SS(); while(SW2); while(!SW2);}
#define lcs lcd_clear_screen();

int key= 0, key_puck;

#define ab45    wa = 90; AB(0,0,4,184,5,167,50,0); cw
#define ab345(y) wa = 90; AB(3,126,4,184,5,167,50,y); cw
#define ab645(y) wa = 90; AB(6,144,4,184,5,167,50,y); cw

#define ab865(y) AB(5,195,6,173,8,125,30,y); cw

#define ab134(y) AB(4,188,1,165,3,158,30,y); cw
#define ab86 AB(0,0,6,136,8,112,50,0);

#define ab0 AB(0,166,0,0,0,0,0,30); cw

#define tx 151
#define ty 162


#define color(n) colorPos[tri_cnt][n]
#define colorX(n) colorPos[tri_cnt][n] % 5 
#define colorY(n) colorPos[tri_cnt][n] / 5

int index = 0,max = 0,first;
int temp = 0;
int cnt = 0;
int threePos = -1;
int putPos[25] = {0},last = 0;

#define swap(a,b) temp = a; a = b; b = temp;

//������ ������ ���� / --> dx / dy 


int map[25] = {
0
};

int posList[16];
int min = 0;
int colorPos[5][3] = {0};
int g_colorPos[5][3] = {0};
int territory[25] = {0};
int array[3][25] = {0};

int f_flg = 0;//b / r�� ��� 1�̸� f_flg = 1 


int Finish(int *node, int *nodeStack){
   for(int i = 0 ; i < 25 ; i++){
      if(!node[i]) continue; // ���� ��ŵ 
      if(nodeStack[i] != node[i]) return 0;
   }
   return 1;
}

int SetTerritory(int *points, int *output) {
    int cpPoints[3] = {0};
   
	memcpy(cpPoints,points,sizeof(cpPoints));
	memset(output,0,sizeof(int)*25);
   
  	for(int j =  0 ; j < 2 ; j++)
   		for(int i = 0  ; i < 2 ; i++)
       		if(cpPoints[i] % 5 > cpPoints[i+1] % 5){
           		swap(cpPoints[i],cpPoints[i+1]);
       		}
   
   //������ x��ǥ ������ ����  
   	int p[3][2] = {0},dx[3],dy[3];
   	float grad[3] = {0}; // 0 : 0 - 1 | 1 : 1 - 2 | 2 : 2 - 3 

    for(int i = 0 ; i < 3 ; i++){
      p[i][0] = cpPoints[i]/5; //����Ʈ�� y��ǥ    
      p[i][1] = cpPoints[i]%5; //����Ʈ�� x��ǥ 
      output[cpPoints[i]] = 2;   
   }
   
   for(int i = 0 ; i < 3 ; i++){
      dx[i] = p[i][1] - p[(i+1)%3][1];
      dy[i] = p[i][0] - p[(i+1)%3][0];
       
      grad[i] = (dy[i])? (float)dx[i]/dy[i] : 99;
   }

   	for(int i = 0 ; i < 3 ; i++){
      	if(grad[i] == 99 && abs(dx[i]) > 1){ 
           int s = (dx[i] > 0)? p[(i+1)%3][1] : p[i][1];
           int e = (dx[i] > 0)? p[i][1] : p[(i+1)%3][1];
         
           for(int j = s + 1 ; j < e ; j++)   output[p[i][0] * 5 + j] = 2;
        }
      
      	else{
	        int s = p[i][0];
	        int e = p[(i+1)%3][0];
	        int sx = p[i][1];
	          
         	if(s > e){
            	swap(s,e);
              	sx = p[(i+1)%3][1];
           	}
       
            for(int j = s + 1 ; j < e ; j++){
               	float nx = sx + ((j-s) * grad[i]);
               
               	if((int)(nx) < nx){
                	nx = (nx > p[1][1])? (int)ceil(nx) : (int)floor(nx);
                	output[j * 5 + (int)nx]= 1;
               	}   
               	
                else   output[j * 5 + (int)nx]= 2;            
            }
        }
   	}
   	
	int width = 0,flg = 0;
   
   	for(int i = 0 ; i < 5 ; i++){
       int cnt = 0,sx = -1;
      
       for(int j = 0 ; j < 5 ; j++){   
         	if(output[i*5 + j]) {
               cnt ++;
               sx = (sx == -1)? j : sx;
           	}
       	}
       
      if(cnt == 2){   
      		if(threePos < 0 || territory[threePos] == 3) flg = 1;
      	
			for(int j = sx + 1 ; !output[i*5 + j] ; j++){       
	            int point = i * 5 + j;
	            if(point == threePos && territory[threePos] < 3) flg = 1; // threePos�� ä������ ���� ���¿��� 3�� �������� �ʴ� ��� 
				
				output[point] = 3;         
	               
	           	if(map[point]){
	            	if(map[point] <= territory[point])   return 0;
	        		width++;   
	           	}
	        }
    	}
    }  
	
	if(!flg) return 0;
   	return width;
}



void TriangleDFS(int posIndex, int countIndex, int tri_cnt){   
    cnt++;
      
    if(posIndex > 16 || tri_cnt > min || f_flg) return;
   
    if(tri_cnt == min){//�ﰢ�� �ϼ� ����
        f_flg = Finish(map,territory);  //�ϼ��� ��� return 1 �ƴϸ� 0
            
      	for(int i = 0 ; i < 3 ; i++)
        	memcpy(g_colorPos[i],colorPos[i],sizeof(colorPos[i]));
    }
      
    else{
        if(countIndex < 3){    //���� �� 3�� Select �ȵ� ��� 
           	if(posIndex > 15) return;
         
           	int nowPos = posList[posIndex],start = 1;
           	
			colorPos[tri_cnt][countIndex] = nowPos;
            
           	if(countIndex > 1)
               if(abs(colorX(0) - colorX(1)) <= 1 && abs(colorY(0) - colorY(1)) <= 1) return;
            
           	else if(countIndex > 1){
            	if(abs(colorX(2) - colorX(1)) <= 1 && abs(colorY(2) - colorY(1)) <= 1) start = 0;
            	if(abs(colorX(2) - colorX(0)) <= 1 && abs(colorY(2) - colorY(0)) <= 1) start = 0;
           	}
            
           	for(int i = start; i >= 0 && !f_flg; i--)
            	TriangleDFS(posIndex+1,countIndex+i,tri_cnt); //���� ������ �˻�     
        }
         
        else{   //�� ���� Select �Ϸ�� ���          
            for(int j = 0 ; j < tri_cnt ; j++){
               for(int i = 0 ; i < 3 ; i++){
                  if(colorPos[tri_cnt][i] != colorPos[j][i]) break; //�ߺ����� 
                  if(i == 2) return;
               }
           	}
           
         	int last_index;
            
			int wid = SetTerritory(colorPos[tri_cnt],array[tri_cnt]);
            
			if(!wid || (tri_cnt == 0 && wid < first)) return; //�� ó���� ��� 3�� ����!!  
            
            for(int i = 0 ; i < 25 ; i++)   
            	if(array[tri_cnt][i] == 3 && map[i])   territory[i]++;
            
			for(int i = 0 ; i < 16 ; i++)
	            if(posList[i] == colorPos[tri_cnt][0]) last_index = i;
        
          	TriangleDFS(last_index,0,tri_cnt+1); 
        
           	for(int i = 0 ; i < 25 ; i++)
            	if(array[tri_cnt][i] == 3 && map[i]) territory[i]--;               	
        }
   } 
   return;
}


int main(void)
{


   Interface_init();

   write_gyro(0x1E, 1); // ���ڱ� OFF
   write_gyro(0x1E, 5); // ���̷� 500dps   
   write_gyro(0x1E, 20); // �ɵ��� ������������ OFF

   write_gyro(0x1E, 16); // ���̷� ����

   
   Camera_init();
   Setting(11);
   TM(80);
   V3
   
   
   _delay_ms(500);

   set

   LED_ON(3);
   _delay_ms(100);
   LED_OFF(3);

   while(1)
   {      
       if(SW1)
      {
         key--;
         _delay_ms(70);
         LED_ON(3);
         _delay_ms(100);
         LED_OFF(3);
      }
       if(SW3)
      {
         key++;
         _delay_ms(70);
         LED_ON(3);
         _delay_ms(100);
         LED_OFF(3);
      }
      
      
       if(SW2)
      {
         lcd_clear_screen();

         switch(key)
         {

case 0:
case 1:

//45�� 1-14, 8-20, 4-18, 6-16, 3-19, 5-15
//40�� 1-11, 8-15, 4-14, 6-12, 3-15, 5-11

//180


//// Home ��ġ�� �̵� 
ar ab45(30);
Drift(0,50,30,60,70);	wa=30;
Axis(0,97,0,60,0);
Ot(30,90,10,55,0); wa = 40;
Axis(-15,0,0,60,0);
Drift(-47,0,-40,50,-60);	cw //25

case 2:

ar ab134(20);


// ��ĵ ���� 
//=======
Axis(0,5,0,50,60);
Ot(28,-90,0,45,0);



MoveLineCheck(0,1000,0,0,40,0);
Axis(5,0,0,40,-50);
MoveLineCheck(0,-1000,0,0,20,130);

//

map[6 + 10] = Scan(151,166);

MoveLine(0,0,15,30,140);

map[6 + 5] = Scan(141,95);
map[6] = Scan(134,18);

Ot(-15,90,0,30,40);


MoveLineCheck(0,1000,0,0,40,0);
Axis(5,0,0,40,-50);
MoveLineCheck(0,-1000,0,0,20,130);

//==========

map[17] = Scan(151,166);

MoveLine(0,0,15,30,140);

map[12] = Scan(141,95);
map[7] = Scan(134,18);

Ot(-15,90,0,30,40);
MoveLineCheck(0,1000,0,0,40,0);
Axis(5,0,0,40,-50);
MoveLineCheck(0,-1000,0,0,20,130);


//=======

map[8 + 10] = Scan(151,166);

MoveLine(0,0,15,30,140);

map[8 + 5] = Scan(141,95);
map[8] = Scan(134,18);





for(int i = 0 ; i < 3 ; i++){
	lcd(i,0,"%d %d %d",map[(5 *i) + 6],map[(5 *i) + 6 + 1],map[(5 *i) + 6 + 2]);
}


Axis(40,-45,0,50,160);

case 5:
ar ab865(20);
SS();

if(key == 5) {
	map[8] = 2;
	map[12] = 2;
	map[16] = 2;
	map[18] = 3;
}


for(int i = 0; i < 25 ; i++){
   if(map[i] == 3) threePos = i;
   if(map[i]) first++;

   if(i / 5 == 0 || i / 5 == 4 || i % 5 == 0 || i % 5 == 4) 
       posList[index++] = i;
  
   max = (max < map[i])? map[i] : max;
} 

_delay_ms(100); //�ý���  ���ð�
         
for(int i = max ; i <= 4 ;  i++){
   min = i;
   TriangleDFS(0,0,0);
   _delay_ms(100); //�ý���  ���ð�
   if(f_flg) break;
}


LED_ON(3);
_delay_ms(100);
LED_OFF(3);





case 3:



for(int p = 0 ; p < 25 ; p++){
	for(int i = 0  ; i < min ; i++){
		for(int j = 0  ; j < 3 ; j++){
			if(p == g_colorPos[i][j]) 
				putPos[p] = 1;
		}
	}
}

for(int i = 0,cnt = 0  ; i < 25 ; i++){
	if(putPos[i]){
		getPuck(cnt++);
		PutPuck(i);
	}
}

GoHome();

LED_ON(3);
_delay_ms(2000);
LED_OFF(3);


lcs
lcd(0,15,"min:%d",min);

for(int i = 0 ; i < min ; i++){
	lcd(i,0,"%d %d %d",g_colorPos[i][0],g_colorPos[i][1],g_colorPos[i][2]);
}	


SS();




while(!SW2);
while(SW2);

         }
      }

      if(key){
         lcd(0,0,"%03d %03d %03d %03d %03d",g_psd[2],g_psd[1],g_psd[0],g_psd[8],g_psd[7]);
         lcd(1,0,"%03d %03d      %03d %03d",g_psd[3],g_psd[4],g_psd[5],g_psd[6]);
      }
      else{
         lcd(0,0,"%03d %03d %03d %03d %03d",psd[2],psd[1],psd[0],psd[8],psd[7]);
         lcd(1,0,"%03d %03d      %03d %03d",psd[3],psd[4],psd[5],psd[6]);
      }
      key_puck = abs(key) %9;

      get_gyro();
      lcd(2,0,"C%d X%3d Y%3d S%2d",key_puck,Cmd(key_puck,102),Cmd(key_puck,103),Cmd(key_puck,104));      
      lcd(3,0,"%d%d%d%d%d|%d%d G%04d",IR_4,IR_1,IR_2,IR_3,IR_5,IND_1,IND_2, (int)gyro);
      lcd(3,16,"k:%02d",key);
   }
}


int Scan(int x, int y){
	SS();


	for(int t = 0 ; t < 3 ; t++){
		SV1
		V1();
		V3	
	
		for(int i = 0 ; i < 9 ; i++){
			if(!pro[i][0] || pro[i][0] > 3) continue;
			if(abs(pro[i][1] - x) < 30 && abs(pro[i][2] - y) < 30) {return pro[i][0];}	
		}
	}
	return 0;
}


void PutPuck(int index){
	ar ab865(20);
	SS();
	ar ab865(20);
	SS();
	
	
	int x = (4 - (index % 5)) * 35;
	int y = (4 - (index / 5)) * 35;
	

	

	if(index == 4 || index == 9 || index == 14 || index == 19){
		CPsd(12,8,5,3,16,0,50,60);
		CPsd(10,8,y + 3,5,16,0,50,0);
		Ot(12,90,0,45,-55);

		Axis(0,-15,0,25,25);
		Ot(-5,90,10,25,0);	wa = -80;
		Ot(-5,-90,10,25,0);	wa = 20;	
		

		CPsd(12,5,-5,3,14,0,35,0); y -= 35;
		CPsd(10,5,(y > 25)? -y + 25 : 0 ,5,14,0,40,0);
		CPsd(-4,5,-1000,5,14,25,40,0);
		Ad(0,-10,-20,40,-50,30);	cw	

	}
	else if(index == 0 || index == 1 || index == 2 || index == 3){
		CPsd(12,8,10,3,18,0,60,70);
		CPsd(10,8,180 - 10 - 40,5,18,0,60,0);
		Drift(-3,40,90,50,-60);

		ar ab645(30);
		
		int spd = (index % 5 != 3)? 50 : 30;
		CPsd(12,8,10,3,18,0,spd,spd + 10);
		CPsd(10,8,x - 30,5,18,0,spd,0);
		Ot(5,90,0,spd - 10,-spd); 
	

		if(index == 3){
			Axis(0,(x > 25)? -x + 25 : 0,0,40,50);
		
			ab45(50);
			ar ab645(30);
		
			Drift(-30,1,-70,45,55);	wa = 20;
			CPsd(12,5,-5,3,14,0,60,0);
			CPsd(10,5,-130,3,14,0,60,0);
			CPsd(4,5,-1000,5,14,25,60,0);
			Ad(0,-5,-20,60,-70,30);	cw
		}
		else{
			int r = 107 - (35 * (index % 5));
			
			Axis(0,-15,0,50,60);
			Ot(-r,-90,-30,50,0);	wa = 60;

			CPsd(12,4,-5,3,14,0,50,0);
			CPsd(10,4,-20 - (35 * (index % 5)),5,14,0,50,0);
			CPsd(-3,4,-1000,5,14,25,50,0);
			Ad(0,-10,-60,50,-60,60);	cw
		}
	}
					
	else if(index >= 20 && index != 24){
		Drift(-3,44,90,40,150);	
		ar ab45(30);
		MLC();
		ar ab45(30);
		
			
		MoveLine(10,0,21 + 35 * (3 - (index % 5)),50,160);
		
		Axis(0,-15 - 35 * (3 - (index % 5)),0,40,50);
		ab45(50);
		ar ab45(30);

		Drift(-39,2,-90,30,140);	
	}
	
	
	else if(index % 5 == 0){
		Axis(-160,2,0,60,170);
		ar ab134(30);
		
		CPsd(12,1,5,3,12,0,50,60);
		CPsd(10,1,y + 1,5,12,0,50,0);
		Ot(12,-90,0,45,-55);

		Axis(0,-15,0,25,25);
		Ot(-5,-90,-10,25,0);	wa = 80;
		Ot(-5,90,-10,25,0);	wa = -20;	 
		
		CPsd(12,4,-5,3,16,0,35,0); y -= 35;
		CPsd(10,4,(y > 25)? -y + 25 : 0 ,5,16,0,40,0);
		CPsd(-5,4,-1000,5,16,25,40,0);
		Ad(0,-10,20,40,-50,30);	cw	
		ar ab134(30);

		Axis(160,2,0,60,170);


	}

	else{
		Axis(-10,21,0,30,140);
		Axis(0,-21,0,30,140);
		Axis(10,0,0,30,140);
	}

	SS(); ar ab865(20); SS();
}



void getPuck(int n) {
	ar ab865(30); SS();
	if(n<6) {
		
		Drift(-15,0,-10,40,50);	wa=90;
		
		Ot(-33,90,-60,40,0); wa=-70;
		if(n!=5) {
			Axis(0,-65-(20*n),0,50,-60); cw
			Setting(13);
			ar TB(1,0,tx,ty);

			Axis(0,10,0,30,40);
			Ad(-5,20,90,30,-40,60); wa=-70;
			Ot(20,-90,0,40,50); wa=20;
			Axis(0,35+(20*n),0,50,0);
	
			Ot(20,-90,-20,40,0); cw
			Axis(17,0,0,40,-50);
			ar ab865(30);
			
		}
		else {
			Drift(0,-125,-30,50,0); wa=-10;
			MovePsd(0,7,1000,0,0,25,50,0);
			Drift(12,0,10,35,-45); cw
			ar TB(1,0,tx,ty);

			Axis(0,15,0,30,40);
			Drift(-3,28,90,25,0);
			CPsd(12,8,10,3,18,0,60,70);
			CPsd(10,8,63,5,18,0,60,0);
			Ot(30,90,20,45,0); wa=-70;
			Ot(10,-90,0,40,0); wa=20;
			Axis(0,40,0,50,0);

			Ot(20,-90,-20,40,0); cw
			Axis(20,0,0,40,-50);
			ar ab865(30);		
		}	
	}

// 30 // 60 
// 28

	else{
		ar ab865(30);
		At(20,40);	wa = -70; SS();
		Axis(0,110-23,0,55,65);
		Ot(27,90,0,50,0); wa = 20;
		
		if(n != 11){
			Axis(0,-50-(20*(n%6)),0,50,0); cw
			Ad(0,-10,50,40,-50,80);	cw
			Setting(13);
			ar TB(1,0,tx,ty);

			Axis(0,10,0,30,40);
			Ad(5,20,-90,30,-40,60); wa=-20; SS();
			Ot(20,-90,0,40,50); 
			Axis(60,0,0,50,0);	wa = 70;
			
			Ot(20,90,0,50,0); wa = -20; // 35 50
			Axis(0,20 + (20 * (n % 6)),0,60,0);
			
			Ot(20,-90,0,50,0);	
			Drift(17,0,20,45,-55);	cw
			
			ar ab865(30);
			
		}
		else{
			Axis(0,-125,0,60,0);
			MovePsd(0,4,0,-1000,0,25,60,0);
			Ad(0,-12,70,50,-60,80);		cw
			ar TB(1,0,tx,ty);

			Axis(0,15,0,30,40);
			Drift(3,28,-90,25,0);
			CPsd(12,1,10,3,16,0,60,70);
			CPsd(10,1,60,5,16,0,60,0);
			Ot(20,-90,0,45,0); wa = 90;
			Drift(0,20,-20,40,0);	wa =70;
			Axis(0,60,0,50,0);	
			Ot(20,90,0,40,0); wa=-20;
			Axis(0,40,0,50,0);
			Ot(20,-90,0,40,0);
			Drift(17,0,20,30,-40);	cw
				
				
		}
	}

	ar ab865(30);
	SS();

}

//3
void GoHome(int index){
	//index != 20�϶��� 
	
	ar ab865(30);
	
	
	Drift(-20,0,20,30,40);	wa = 20;
	Axis(-26,0,0,40,0);		wa = -70;
	Ot(20,90,0,35,0);		wa= 20;
	
	MoveLineCheck(0,0,-1000,0,50,0);
	Axis(0,-8,0,50,-60);

	LED_ON(3);
	_delay_ms(2000);
	LED_OFF(3);

}

void MLC(){
	MoveLineCheck(0,-2,0,0,10,120);
	MoveLineCheck(0,4,0,0,10,120);
	MoveLineCheck(0,-6,0,0,10,120);
	MoveLineCheck(0,8,0,0,10,120);
	MoveLineCheck(0,-10,0,0,10,120);
	MoveLineCheck(0,12,0,0,10,120);
	MoveLineCheck(0,-14,0,0,10,120);
	MoveLineCheck(0,16,0,0,10,120);

}
